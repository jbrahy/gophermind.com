# Requirements

## Active

### PROV-01 — System supports Anthropic Claude API with streaming responses

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

System supports Anthropic Claude API with streaming responses

### PROV-02 — System supports OpenAI API (Chat Completions) with streaming responses

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

System supports OpenAI API (Chat Completions) with streaming responses

### PROV-03 — System supports Google Gemini API with streaming responses

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

System supports Google Gemini API with streaming responses

### PROV-04 — System supports Ollama local models with streaming responses

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

System supports Ollama local models with streaming responses

### PROV-05 — All providers implement a unified Provider interface (Complete, Stream, HealthCheck, GetCost)

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

All providers implement a unified Provider interface (Complete, Stream, HealthCheck, GetCost)

### PROV-06 — Provider requests are normalized across different API formats

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Provider requests are normalized across different API formats

### PROV-07 — Provider failures retry up to 3 times with exponential backoff (1s, 2s, 4s)

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Provider failures retry up to 3 times with exponential backoff (1s, 2s, 4s)

### PROV-08 — Failed provider falls back to equivalent-tier provider from different vendor

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Failed provider falls back to equivalent-tier provider from different vendor

### PROV-09 — Provider health checks detect unavailability before routing requests

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Provider health checks detect unavailability before routing requests

### PROV-10 — All provider calls log token usage, cost, duration, and success/failure to JSONL

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

All provider calls log token usage, cost, duration, and success/failure to JSONL

### COST-01 — Every LLM call records input tokens, output tokens, and calculated cost

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Every LLM call records input tokens, output tokens, and calculated cost

### COST-02 — Costs accumulate per provider, per agent, and per tier in costs.jsonl

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Costs accumulate per provider, per agent, and per tier in costs.jsonl

### COST-03 — User can view cost breakdown via `gsd costs --breakdown`

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

User can view cost breakdown via `gsd costs --breakdown`

### COST-04 — Per-run budget cap prevents runaway costs (configurable in config.json)

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Per-run budget cap prevents runaway costs (configurable in config.json)

### ROUT-01 — Task-based routing assigns providers/models by task category (architecture, code gen, summarization, etc.)

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Task-based routing assigns providers/models by task category (architecture, code gen, summarization, etc.)

### ROUT-02 — Routing rules are configured in config.json, not hardcoded

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Routing rules are configured in config.json, not hardcoded

### ROUT-03 — Routing respects model tier assignments (fast/balanced/powerful)

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Routing respects model tier assignments (fast/balanced/powerful)

### ROUT-04 — Tier escalation occurs when all same-tier providers fail on critical tasks

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Tier escalation occurs when all same-tier providers fail on critical tasks

### STAT-01 — All project state persists in .planning/ directory as structured files

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

All project state persists in .planning/ directory as structured files

### STAT-02 — STATE.md tracks current phase, task, progress, decisions, risks, and metrics

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

STATE.md tracks current phase, task, progress, decisions, risks, and metrics

### STAT-03 — File writes use atomic temp-file-rename pattern to prevent corruption

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

File writes use atomic temp-file-rename pattern to prevent corruption

### STAT-04 — JSONL log appends use single-writer goroutine for concurrency safety

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

JSONL log appends use single-writer goroutine for concurrency safety

### STAT-05 — In-progress runs are detected via PID/lock files

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

In-progress runs are detected via PID/lock files

### STAT-06 — System is fully resumable after interruption — reads state from disk on restart

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

System is fully resumable after interruption — reads state from disk on restart

### STAT-07 — Checkpoint markers in STATE.md enable resume from last completed step

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Checkpoint markers in STATE.md enable resume from last completed step

### AGNT-01 — Each agent has a machine-readable contract: inputs, outputs, success criteria, failure modes

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Each agent has a machine-readable contract: inputs, outputs, success criteria, failure modes

### AGNT-02 — Agent execution follows 7-step protocol: load → context → select provider → execute → validate → write → handoff

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Agent execution follows 7-step protocol: load → context → select provider → execute → validate → write → handoff

### AGNT-03 — Agents are pure functions (context in, output out) — the executor owns disk writes

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Agents are pure functions (context in, output out) — the executor owns disk writes

### AGNT-04 — Agent output is validated against success criteria before acceptance

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Agent output is validated against success criteria before acceptance

### AGNT-05 — Handoff validation rejects malformed agent output

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Handoff validation rejects malformed agent output

### AGNT-06 — System includes 12+ specialized agents: Researcher, Architect, Requirements Synthesizer, Roadmapper, Go Conventions Guardian, Test Strategist, Security Reviewer, Operations Planner, State Keeper, Code Generator, Code Reviewer, Debugger

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

System includes 12+ specialized agents: Researcher, Architect, Requirements Synthesizer, Roadmapper, Go Conventions Guardian, Test Strategist, Security Reviewer, Operations Planner, State Keeper, Code Generator, Code Reviewer, Debugger

### AGNT-07 — Agent prompts are versioned; version IDs are embedded in JSONL logs

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Agent prompts are versioned; version IDs are embedded in JSONL logs

### AGNT-08 — Per-agent context budget enforcement prevents context window exhaustion

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Per-agent context budget enforcement prevents context window exhaustion

### ORCH-01 — Workflow orchestrator coordinates agent execution sequences

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Workflow orchestrator coordinates agent execution sequences

### ORCH-02 — Task dependency graph determines execution order (topological sort)

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Task dependency graph determines execution order (topological sort)

### ORCH-03 — Independent agents execute in parallel via errgroup

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Independent agents execute in parallel via errgroup

### ORCH-04 — Dependent agents block until predecessors complete

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Dependent agents block until predecessors complete

### ORCH-05 — Phase transitions are enforced — cannot advance without exit criteria met

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Phase transitions are enforced — cannot advance without exit criteria met

### ORCH-06 — Orchestrator handles resumption after interruptions using STATE.md

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Orchestrator handles resumption after interruptions using STATE.md

### CLI-01 — `gsd init` runs wave-based questioning and produces planning artifacts

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

`gsd init` runs wave-based questioning and produces planning artifacts

### CLI-02 — `gsd status` displays current phase, task progress, and metrics

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

`gsd status` displays current phase, task progress, and metrics

### CLI-03 — `gsd resume` continues interrupted workflow from last checkpoint

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

`gsd resume` continues interrupted workflow from last checkpoint

### CLI-04 — `gsd view <artifact>` displays planning artifacts with formatting

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

`gsd view <artifact>` displays planning artifacts with formatting

### CLI-05 — `gsd verify` runs verification checks against planning artifacts

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

`gsd verify` runs verification checks against planning artifacts

### CLI-06 — `gsd logs [--provider]` shows structured event and provider logs

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

`gsd logs [--provider]` shows structured event and provider logs

### CLI-07 — `gsd costs [--breakdown]` displays cost breakdown by provider/agent/tier

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

`gsd costs [--breakdown]` displays cost breakdown by provider/agent/tier

### CLI-08 — `gsd config [--edit]` views or modifies configuration

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

`gsd config [--edit]` views or modifies configuration

### CLI-09 — CLI streams LLM output to terminal in real-time (not buffered)

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

CLI streams LLM output to terminal in real-time (not buffered)

### CLI-10 — CLI displays agent progress indicators during execution

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

CLI displays agent progress indicators during execution

### INIT-01 — Wave-based questioning protocol (8 waves) gathers complete project context

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Wave-based questioning protocol (8 waves) gathers complete project context

### INIT-02 — Produces PROJECT.md with mission, requirements, constraints, decisions

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Produces PROJECT.md with mission, requirements, constraints, decisions

### INIT-03 — Produces config.json with all workflow settings

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Produces config.json with all workflow settings

### INIT-04 — Research phase spawns 4 parallel researcher agents

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Research phase spawns 4 parallel researcher agents

### INIT-05 — Requirements synthesis generates numbered, testable requirements

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Requirements synthesis generates numbered, testable requirements

### INIT-06 — Roadmapper creates phased delivery plan mapped to requirements

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Roadmapper creates phased delivery plan mapped to requirements

### INIT-07 — All init artifacts are committed to git

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

All init artifacts are committed to git

### INIT-08 — Partial answers are saved on interruption for resume

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Partial answers are saved on interruption for resume

### GINT-01 — Detects Go modules (go.mod parsing) and workspaces (go.work)

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Detects Go modules (go.mod parsing) and workspaces (go.work)

### GINT-02 — Builds package dependency graph for target repository

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Builds package dependency graph for target repository

### GINT-03 — Identifies test files, benchmarks, and examples

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Identifies test files, benchmarks, and examples

### GINT-04 — Checks Go conventions: package layout, naming, error wrapping, context usage

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Checks Go conventions: package layout, naming, error wrapping, context usage

### GINT-05 — Enforces structured logging patterns (slog usage)

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Enforces structured logging patterns (slog usage)

### GINT-06 — Generates repository intelligence summary for agent context

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Generates repository intelligence summary for agent context

### GINT-07 — Distinguishes internal vs public API packages

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Distinguishes internal vs public API packages

### VERF-01 — Coverage checks verify every requirement appears in at least one phase

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Coverage checks verify every requirement appears in at least one phase

### VERF-02 — Consistency checks verify architecture matches v1 scope

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Consistency checks verify architecture matches v1 scope

### VERF-03 — Completeness checks verify no placeholder text or TODOs in artifacts

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Completeness checks verify no placeholder text or TODOs in artifacts

### VERF-04 — Alignment checks verify out-of-scope items are documented

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Alignment checks verify out-of-scope items are documented

### VERF-05 — Semantic alignment checks compare implementation against spec artifacts

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Semantic alignment checks compare implementation against spec artifacts

### VERF-06 — Verification results are logged to events.jsonl

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Verification results are logged to events.jsonl

### CONF-01 — config.json stores all system settings with sensible defaults

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

config.json stores all system settings with sensible defaults

### CONF-02 — Configuration supports mode (interactive/yolo), granularity, parallelization

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Configuration supports mode (interactive/yolo), granularity, parallelization

### CONF-03 — LLM settings: multi-provider, routing mode, fallback, retry, timeout

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

LLM settings: multi-provider, routing mode, fallback, retry, timeout

### CONF-04 — Go settings: conventions enforcement, tool paths, coverage targets

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Go settings: conventions enforcement, tool paths, coverage targets

### CONF-05 — Safety settings: file write permissions, command execution restrictions

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Safety settings: file write permissions, command execution restrictions

### CONF-06 — Logging settings: level, structured format, file paths

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Logging settings: level, structured format, file paths

### LOG-01 — Structured event log (events.jsonl) records agent lifecycle events

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Structured event log (events.jsonl) records agent lifecycle events

### LOG-02 — Provider call log (provider-calls.jsonl) records every LLM API call

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Provider call log (provider-calls.jsonl) records every LLM API call

### LOG-03 — Cost log (costs.jsonl) tracks cumulative spending

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Cost log (costs.jsonl) tracks cumulative spending

### LOG-04 — Application logging uses slog with JSON output

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Application logging uses slog with JSON output

### LOG-05 — Log levels: debug, info, warn, error — configurable at runtime

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Log levels: debug, info, warn, error — configurable at runtime

### GIT-01 — Agent file writes are auto-committed with descriptive messages

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Agent file writes are auto-committed with descriptive messages

### GIT-02 — Planning artifacts in .planning/ are git-tracked

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Planning artifacts in .planning/ are git-tracked

### GIT-03 — Phase-based branching strategy supported (configurable)

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Phase-based branching strategy supported (configurable)

### SEC-01 — API keys stored in environment variables, never in committed files

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

API keys stored in environment variables, never in committed files

### SEC-02 — Source code privacy: code only sent to providers when explicitly configured

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Source code privacy: code only sent to providers when explicitly configured

### SEC-03 — File system writes restricted to project directory

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

File system writes restricted to project directory

### SEC-04 — Command execution requires explicit approval (configurable)

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

Command execution requires explicit approval (configurable)

### SEC-05 — All security-relevant actions logged for audit

- Status: active
- Class: core-capability
- Source: inferred
- Primary Slice: none yet

All security-relevant actions logged for audit

## Validated

## Deferred

## Out of Scope
