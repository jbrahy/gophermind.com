# GSD Overrides

User-issued overrides that supersede plan document content.

---
## Override: 2026-03-23T10:32:08.719Z

**Change:** Stop planning. Convert the existing slice plan for S01 into concrete tasks immediately. Tasks should be small, actionable, and ready for execution in this repository.
**Scope:** active
**Applied-at:** M001/S01/none

---

## Override: 2026-03-23T10:33:08.634Z

**Change:** Do not call any external tools such as search, browser, or fetch. Only use built-in GSD commands and local repository context.
**Scope:** active
**Applied-at:** M001/S01/none

---

## Override: 2026-03-23T10:33:18.422Z

**Change:** You are running inside GSD. Only use GSD-native commands and local repo tools. Do not invent or call external tools.
**Scope:** active
**Applied-at:** M001/S01/none

---

## Override: 2026-03-23T10:52:20.603Z

**Change:** Use the Tasks section in S01 Foundation to create executable task artifacts now. Do not rewrite the slice plan again unless required fields are missing.
**Scope:** active
**Applied-at:** M001/S01/none

---
