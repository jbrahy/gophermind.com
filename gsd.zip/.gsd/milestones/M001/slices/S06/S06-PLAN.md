# S06: Go Intelligence

**Goal:** unit tests prove Go Intelligence works
**Demo:** unit tests prove Go Intelligence works

## Must-Haves


## Tasks


## Files Likely Touched

