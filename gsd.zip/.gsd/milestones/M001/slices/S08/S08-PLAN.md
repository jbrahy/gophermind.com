# S08: Full Agent Set, Git, Costs, Streaming CLI

**Goal:** unit tests prove Full Agent Set, Git, Costs, Streaming CLI works
**Demo:** unit tests prove Full Agent Set, Git, Costs, Streaming CLI works

## Must-Haves


## Tasks


## Files Likely Touched

