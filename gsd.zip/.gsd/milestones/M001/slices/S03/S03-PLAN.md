# S03: Initialization

**Goal:** unit tests prove Initialization works
**Demo:** unit tests prove Initialization works

## Must-Haves


## Tasks


## Files Likely Touched

