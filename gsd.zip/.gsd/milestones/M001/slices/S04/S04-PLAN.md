# S04: Orchestration and Core CLI

**Goal:** unit tests prove Orchestration and Core CLI works
**Demo:** unit tests prove Orchestration and Core CLI works

## Must-Haves


## Tasks


## Files Likely Touched

