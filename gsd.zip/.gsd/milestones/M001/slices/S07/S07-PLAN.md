# S07: Extended Providers and Parallel Execution

**Goal:** unit tests prove Extended Providers and Parallel Execution works
**Demo:** unit tests prove Extended Providers and Parallel Execution works

## Must-Haves


## Tasks


## Files Likely Touched

