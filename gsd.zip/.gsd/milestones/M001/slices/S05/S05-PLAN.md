# S05: Verification Gates

**Goal:** unit tests prove Verification Gates works
**Demo:** unit tests prove Verification Gates works

## Must-Haves


## Tasks


## Files Likely Touched

