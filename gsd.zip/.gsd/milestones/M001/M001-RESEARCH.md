# Project Research Summary

**Project:** GopherMind
**Domain:** Go CLI multi-agent LLM orchestration platform (spec-driven development tool)
**Researched:** 2026-03-20
**Confidence:** HIGH

## Executive Summary

GopherMind is a spec-driven, multi-agent LLM orchestration CLI targeting Go developers. The competitive landscape — Aider, Cursor, Kiro, OpenHands — reveals a clear gap: no existing tool combines CLI-first operation, structured spec lifecycle management, specialized agent contracts with explicit success criteria, and Go-specific code intelligence in a single product. The recommended implementation approach is a layered Go CLI built around a narrow Provider interface, a DAG-based agent scheduler, and file-based state persistence in `.planning/`. Every layer is explicit, auditable, and testable — this is not a "chat with your codebase" tool but a deterministic, verification-gated pipeline that produces durable, reviewable artifacts.

The recommended stack is tight: Go 1.23+, Cobra + Viper for CLI structure, official provider SDKs (anthropic-sdk-go v1.27.1, openai-go v3.29.0, google.golang.org/genai, ollama/api), errgroup + semaphore for parallel agent coordination, and renameio for atomic file writes. No external database. No heavyweight framework. A single cross-platform binary with file-based state. The architecture follows a strict component build order — config, state, and provider layers must be solid before any agent logic is written.

The dominant risk class is not technical but behavioral: multi-agent systems fail in production at 41–86.7% rates, primarily from underspecified agent contracts and coordination failures, not from infrastructure problems. The second major risk is cost explosion from unguarded retry loops across 12+ agents. Both risks are addressed by building cost instrumentation and agent contract validation into the core execution protocol from day one — not as observability afterthoughts. Prompt drift, context window exhaustion, and spec-to-code drift round out the critical pitfall set and are best addressed by pinning model versions, budgeting context per agent call, and building semantic alignment checks into verification gates.

## Key Findings

### Recommended Stack

The stack is narrow by design and all core libraries are verified as of March 2026. Go 1.23 is the effective minimum (driven by Viper v1.21 and backoff v5). The official SDKs for all four providers are confirmed stable: Anthropic SDK reached v1+ in early 2026, openai-go v3 is the current official replacement for the community fork, google.golang.org/genai is GA and replaces the deprecated generative-ai-go (deprecated Nov 30, 2025 — do not use). For concurrency, golang.org/x/sync/errgroup with a weighted semaphore is the correct tool for agent fanout. No DI framework, no gRPC, no database — manual constructor injection and file I/O are sufficient and keep the binary cross-compilable.

**Core technologies:**
- Go 1.23+: Single cross-platform binary, explicit error handling, strong stdlib concurrency — matches target audience
- github.com/spf13/cobra v1.10.2: CLI command structure — de facto standard (Kubernetes, GitHub CLI), shell completions, help generation
- github.com/spf13/viper v1.21.0: Config layering (flags > env > config.json > defaults) — natural Cobra companion, Go 1.23+ required
- log/slog (stdlib): Structured JSONL logging — zero external dependency, concurrent-safe, idiomatic for Go 1.21+
- golang.org/x/sync (errgroup + semaphore): Parallel agent execution with context cancellation and bounded concurrency
- github.com/anthropics/anthropic-sdk-go v1.27.1: Official Anthropic SDK, v1+ stable with streaming and tool use
- github.com/openai/openai-go/v3 v3.29.0: Official OpenAI SDK replacing community forks
- google.golang.org/genai v1.51+: Official Google Gen AI SDK (GA), replaces deprecated generative-ai-go
- github.com/ollama/ollama/api v0.18.2: Official Ollama client for local model support
- github.com/cenkalti/backoff/v5: Exponential backoff with jitter for provider retries
- github.com/google/renameio: Atomic file writes (temp → rename) for all .planning/ artifacts

**What not to use:** github.com/google/generative-ai-go (deprecated), github.com/liushuangls/go-anthropic (unofficial), logrus (maintenance mode), SQLite (breaks cross-compilation), heavyweight LLM frameworks (eino adds 35+ transitive deps), Uber Fx or Wire (DI containers not warranted for a CLI).

### Expected Features

GopherMind's feature landscape has 12 P1 must-haves, all needed to validate the core thesis. The spec-driven lifecycle, specialized agent contracts, and verification gates are the primary differentiators — no competitor implements all three. The Go intelligence layer and parallel agent execution are P2 (add after v1 validates the sequential workflow). Web UI, cloud sync, and plugin APIs are explicitly deferred to v2+ to avoid scope explosion before product-market fit.

**Must have — table stakes (users expect these at launch):**
- Multi-provider LLM support (Anthropic + OpenAI minimum) — foundational; nothing works without this
- Wave-based project initialization (8 waves) — spec-driven entry point; validates the core thesis
- File-based state persistence in `.planning/` — required for resumability and agent handoffs
- Specialized agent execution protocol with 6 core agents (Architect, Planner, Coder, Reviewer, Tester, Verifier)
- Rule-based task routing — routes tasks to cost-appropriate models; industry data shows 30–70% cost reduction
- Verification gates at phase transitions — blocks phase advance until quality criteria are met
- Cost tracking per session — users need spend visibility before committing to the tool
- Resumable sessions via checkpoint markers — long runs will be interrupted; must work before users trust it
- Structured JSONL event logging — audit trail is part of the value proposition
- Atomic file writes — correctness requirement, not optional
- `init`, `status`, `resume`, `verify`, `logs`, `costs` CLI commands — minimum usable command set
- Git-aware operations (commit after each agent write) — all serious tools do this

**Should have — competitive differentiators (add in v1.x):**
- Go intelligence layer (module graph, convention checks, AST analysis) — no competitor has this; validates Go-specific moat
- Parallel agent execution with DAG scheduler — throughput improvement; defer until sequential execution is solid
- Provider health monitoring and circuit breakers — add when reliability becomes a real user complaint
- Remaining 6+ specialized agents — add as workflows expand beyond core lifecycle
- Ollama / local model support — serves privacy-first users; add after primary providers are stable
- Google Gemini support — third provider after Anthropic + OpenAI are solid

**Defer to v2+:**
- Web UI / dashboard — significant scope; validate CLI value first
- Cloud sync — Git is sufficient for v1; auth + storage is a product pivot
- Plugin / extension API — stabilize internal contracts before making them public
- Non-Go repository support — Go-first is the competitive moat; expand after Go market proven
- Real-time collaboration — single-user tool is correct v1 scope

**Anti-features to refuse:** Full chat/conversational interface (undermines spec-driven value prop), auto-approve all agent actions (destroys trust on failure), IDE extensions (orthogonal to CLI), LLM fine-tuning/model hosting (different business).

### Architecture Approach

GopherMind follows a strict layered architecture with a defined component build order. The system has seven internal packages with explicit dependencies: `config` (no internal deps) → `state` + `provider` + `gointel` → `agent` → `orchestrator` → `cmd/`. This order is not arbitrary — it reflects real runtime dependencies and dictates phase sequencing. All disk I/O for planning artifacts is centralized in `internal/state`; agents never write directly to `.planning/`. The provider abstraction is a narrow Go interface with per-provider adapters, not a unified framework.

**Major components:**
1. CLI Layer (cmd/): Cobra commands — thin wiring only, no business logic; delegates to orchestrator
2. Orchestration Layer (internal/orchestrator/): Session lifecycle, DAG construction, parallel task scheduling with errgroup
3. Agent Runtime (internal/agent/): Agent interface + 7-step execution protocol (load def → assemble context → select provider → execute → validate → write artifact → signal handoff)
4. Provider Layer (internal/provider/): Unified Provider interface with per-provider adapters, rule-based router, fallback chain with exponential backoff
5. Go Intelligence Layer (internal/gointel/): Module detection, package graph via `go list`, convention checking — completely standalone from LLM concerns
6. State Layer (internal/state/): Atomic file writes, JSONL event log (single-writer goroutine), cost accumulator
7. Config (internal/config/): Config struct loaded once at startup, passed via dependency injection — no global singleton

**Key patterns:**
- Provider interface with adapter per backend (swappable, testable via mock)
- Rule-based router with fallback chain (auditable, predictable)
- Agent execution protocol as 7 explicit steps (inspectable, resumable, testable per-step)
- DAG scheduler with errgroup for parallel execution (context-canceling, error-propagating)
- Atomic file writes for all planning artifacts (temp → rename; zero corruption risk)

### Critical Pitfalls

Research surfaced 7 critical pitfalls specific to this problem domain. Multi-agent systems fail in production at 41–86.7% rates per ICML 2025 research — this is not an edge concern. The pitfalls are mapped to phases so prevention is built in, not bolted on.

1. **Provider abstraction is syntactic only, not semantic** — Build three layers: syntactic adapter, behavioral contract tests per provider, and a routing layer encoding known behavioral constraints. Never assume prompts are portable across model families. Pin exact model versions (e.g., `claude-3-5-sonnet-20241022`, not `latest`) in production.

2. **Underspecified agent contracts causing coordination failures** — Every agent definition must have machine-readable input schema, output schema, success criteria, and failure behavior. Validate at every handoff. Treat agent contracts as typed interfaces, not prose. Research: 36.94% of multi-agent failures are coordination failures; 79% of all failures originate from specification issues.

3. **Context window exhaustion causing silent failures** — Treat context as a finite budget. Track tokens per agent call; emit warning at 70% of context budget. Use structural metadata (import graphs, call graphs) not raw file content for code intelligence. Test each agent at high context fill levels.

4. **File-based state without durability guarantees** — Atomic writes (temp → rename) for all full file writes. Single-writer goroutine with buffered channel for JSONL appends. PID/lock file to detect abandoned runs. Checkpoint at activity level, not superstep level. os.Rename is NOT atomic on Windows — test explicitly.

5. **Cost explosion from unguarded agent loops** — Cost instrumentation must be part of the Provider interface from day one, not added later. Per-run budget cap that halts execution and writes checkpoint before stopping. Retry limits enforced at agent level. Validate routing rules for exhaustiveness (no task type falls through to unintended model tier).

6. **Prompt drift and model version fragility** — Version every system prompt alongside the code. Build output schema tests for every structured-output prompt. Log every LLM response with prompt_version and model_version. Test prompt changes against a golden output set.

7. **Spec-to-code drift in agent-generated artifacts** — Build spec-alignment checks into verification gates. Maintain decision logs in STATE.md. Use deterministic scaffolding generated from spec before LLM-written implementation to anchor structure.

## Implications for Roadmap

Architecture research explicitly defines a component build order that maps directly to phases. The pitfalls research adds must-address items to early phases (cost instrumentation, durability guarantees, behavioral contract tests). Feature research validates the ordering — multi-provider support and state persistence are foundational P1 items that everything else depends on.

### Phase 1: Foundation — Config, State, and Provider Layer

**Rationale:** Config, state, and provider have no internal dependencies and are prerequisites for everything else. Cost instrumentation and durability guarantees (two of the top pitfalls) must be addressed here or the cost of fixing them later is HIGH.
**Delivers:** Working Provider interface with Anthropic adapter + mock, atomic state writes, JSONL event log with single-writer goroutine, cost recording per provider call, config loading with Viper, exponential backoff and fallback chain.
**Addresses features:** Multi-provider LLM support (Anthropic v1), file-based state persistence, atomic file writes, JSONL event logging, cost tracking infrastructure, error recovery and retry.
**Avoids pitfalls:** Provider abstraction semantic mismatch (behavioral contract tests built alongside), file-based state durability (atomic writes + single-writer JSONL from day one), cost explosion (Provider interface includes cost recording), Cobra/Viper config override (viper.Get* usage enforced).
**Research flag:** Needs research-phase for provider behavioral contract test patterns — streaming event type differences between Anthropic, OpenAI, and Gemini are non-trivial.

### Phase 2: Agent Runtime — Contracts, Execution Protocol, Core Agents

**Rationale:** Agent execution protocol builds on provider layer. Contracts must be designed before implementation — research shows 79% of multi-agent failures originate from specification issues, not technical failures. Six core agents are the minimum viable set to demonstrate the full lifecycle.
**Delivers:** Agent interface, 7-step execution protocol, AgentDefinition struct with machine-readable input/output schemas and success criteria, 6 core agents (Architect, Planner, Coder, Reviewer, Tester, Verifier), prompt versioning infrastructure, output schema validation.
**Addresses features:** Specialized agent contracts (6 core agents), resumable sessions via checkpoint markers, structured output artifacts, git-aware operations.
**Avoids pitfalls:** Underspecified agent contracts (machine-readable schemas enforced at contract definition), prompt drift (prompt versioning and schema validation built at agent layer), LLM-generated command execution (HUMAN_APPROVAL_REQUIRED gate enforced in agent protocol).
**Research flag:** Standard patterns for this phase — agent execution protocols are well-documented in Google ADK and academic literature.

### Phase 3: Wave-Based Init and Context Assembly

**Rationale:** Project initialization (8-wave questioning) depends on agent runtime being functional. Context assembly strategy must be designed before agents are in production use — context window exhaustion is a silent failure mode that is expensive to retrofit.
**Delivers:** `gophermind init` command with 8-wave questioning protocol, context assembly with token budgeting per agent, context fill warnings at 70% threshold, spec artifact structure (SPEC.md, STATE.md, planning directory conventions).
**Addresses features:** Wave-based project initialization, multi-file codebase understanding, structured output artifacts.
**Avoids pitfalls:** Context window exhaustion (token budgeting built into context assembly, not retrofitted), spec-to-code drift (spec artifacts established at project start anchor all downstream agents).
**Research flag:** Standard patterns — wave-based elicitation is a known domain and the 8-wave structure is already defined in PROJECT.md.

### Phase 4: Orchestration and CLI Command Set

**Rationale:** Orchestrator builds on agent runtime and state. DAG scheduler for sequential execution first — parallel comes in Phase 7. Full CLI command set wired to orchestrator makes the tool usable end-to-end for the first time.
**Delivers:** Session Manager (load/save/resume), sequential task scheduler, `gophermind resume` / `gophermind status` / `gophermind verify` / `gophermind logs` / `gophermind costs` commands, streaming output to terminal, progress visibility during agent runs.
**Addresses features:** Resumable sessions, status and progress visibility, streaming output to terminal, `resume`, `status`, `verify`, `logs`, `costs` commands.
**Avoids pitfalls:** Silent progress (structured progress events streamed to stderr), resume disambiguation (list interrupted runs with timestamp, require explicit selection).
**Research flag:** Standard patterns — session lifecycle and DAG scheduling are well-documented.

### Phase 5: Verification Gates

**Rationale:** Gates depend on agent runtime and orchestrator. Spec-to-code drift and underspecified success criteria are two of the top 7 pitfalls — gates are the prevention mechanism. Building gates after agents are running means first real project runs have quality enforcement.
**Delivers:** Phase transition gates with coverage, consistency, and alignment checks; categorized gate failure output (COVERAGE, CONSISTENCY, COMPLETENESS, ALIGNMENT); deterministic scaffolding from spec before LLM implementation; `gophermind verify` command with structured failure reporting.
**Addresses features:** Verification gates between phases.
**Avoids pitfalls:** Spec-to-code drift (semantic alignment gate checks architectural decisions against generated code), verification gates checking only compilation and tests (gates are semantically opinionated, not just `go build && go test`).
**Research flag:** Needs research-phase — AST-based spec-alignment verification against generated code is not well-documented as a standard pattern. The arXiv paper on AST-based hallucination detection (2601.19106) is a starting point but implementation details need validation.

### Phase 6: Go Intelligence Layer

**Rationale:** Go intelligence is a P2 differentiator. It integrates into the context assembly designed in Phase 3 without requiring architectural changes. Deferring this keeps Phase 1-5 focused on the core protocol. Once added, it makes every earlier agent better.
**Delivers:** Go module detection and parsing, package graph via `go list`, convention checking (error wrapping, context propagation, structured logging patterns), integration into agent context assembly for Go-aware prompts.
**Addresses features:** Go intelligence layer (module graph, convention checks, AST analysis) — the primary competitive moat vs. all existing tools.
**Avoids pitfalls:** Context window exhaustion via selective context loading (only relevant packages, not full file tree).
**Research flag:** Needs research-phase — go/packages API, go/ast usage patterns, and `go list` output parsing have nuances worth verifying before implementation.

### Phase 7: OpenAI + Extended Providers and Parallel Execution

**Rationale:** OpenAI is a required v1 provider but can be deferred until sequential execution is proven. Adding it alongside parallel execution and DAG parallelism keeps the two related concurrency concerns in one phase. Provider behavioral contract tests from Phase 1 expand to cover OpenAI.
**Delivers:** OpenAI provider adapter, rule-based router (routing table in config.json), DAG-parallel agent scheduler with semaphore-bounded goroutines, provider health monitoring with circuit breakers.
**Addresses features:** Multi-provider LLM support (both required providers now complete), rule-based task routing, parallel agent execution, provider health monitoring.
**Avoids pitfalls:** Unbound parallel agent goroutines (weighted semaphore caps concurrent LLM calls), rate limit explosion (separate rate limiters per model tier), provider routing exhaustiveness (routing rules tested for completeness).
**Research flag:** Standard patterns for OpenAI adapter — well-documented. Semaphore-bounded errgroup patterns are well-established in golang.org/x/sync.

### Phase 8: Extended Agents, Gemini, Ollama, and Hardening

**Rationale:** Once core workflow is validated, expand the agent set, add remaining providers, and harden against the operational pitfalls that surface during real use.
**Delivers:** 6+ additional specialized agents, Google Gemini provider adapter, Ollama local model support, cost budget cap enforcement, per-run budget warnings in progress output, Windows atomic write testing, `gophermind config` command with effective configuration display.
**Addresses features:** Extended agent set (12+ total), Ollama support, Google Gemini support, provider health monitoring edge cases, full CLI command set.
**Avoids pitfalls:** Cobra/Viper config override (config source visible in `gophermind config` output), Windows atomic write failure (explicit cross-platform test), cost explosion in extended agent workflows (budget cap enforcement at execution engine level).
**Research flag:** Gemini behavioral differences need research-phase — function_declarations vs. OpenAI tools schema, multimodal handling, and streaming event structure are documented as non-equivalent in pitfalls research.

### Phase Ordering Rationale

- **Config → State → Provider must be Phase 1:** Every other component depends on these. Cost instrumentation and durability guarantees retrofitted later have HIGH recovery cost per pitfalls research.
- **Agent contracts before agent logic (Phase 2):** 79% of multi-agent failures originate from specification issues. Contracts must be machine-readable before any agent implementation.
- **Context assembly strategy in Phase 3, not Phase 6:** Context budgeting is a design constraint on agent implementation. Retrofitting it is expensive; doing it before agents run production workloads is cheap.
- **Orchestrator and CLI in Phase 4:** Depends on agent runtime. Enables end-to-end testing for the first time.
- **Verification gates before Go intelligence (Phase 5 before Phase 6):** Gates use Go intelligence when available but must work without it. Build the gate structure first; Go intelligence plugs in as a context source.
- **Parallel execution deferred to Phase 7:** Sequential execution must be reliable first. Parallel adds concurrency complexity that is easier to validate against a working sequential baseline.
- **Extended providers and agents in Phase 8:** Anthropic-only v1 validates the architecture. Gemini and Ollama behavioral differences are better addressed after the provider contract test suite is mature.

### Research Flags

Phases likely needing deeper research during planning:
- **Phase 1:** Provider behavioral contract tests for streaming event type differences — Anthropic, OpenAI, Gemini all have distinct streaming SSE schemas; test patterns need validation
- **Phase 5:** AST-based spec-alignment verification — no established standard pattern; arXiv 2601.19106 is a starting point but implementation approach needs research
- **Phase 6:** go/packages API and go/ast patterns for convention checking — interface nuances worth verifying before committing to implementation approach
- **Phase 8:** Gemini provider behavioral differences — function_declarations schema, streaming semantics, and multimodal handling are non-equivalent to OpenAI tools

Phases with standard patterns (skip research-phase):
- **Phase 2:** Agent execution protocols are well-documented in Google ADK and academic literature
- **Phase 3:** Wave-based elicitation structure is pre-defined; context budgeting patterns are straightforward
- **Phase 4:** Session lifecycle and DAG scheduling in Go are well-documented; errgroup scheduler is a known pattern
- **Phase 7:** OpenAI adapter and semaphore-bounded goroutine patterns are well-established

## Confidence Assessment

| Area | Confidence | Notes |
|------|------------|-------|
| Stack | HIGH | All libraries verified on pkg.go.dev as of March 2026 with exact versions; Go minimum version driven by concrete compatibility constraints (viper v1.21 + backoff v5 require Go 1.23) |
| Features | HIGH | Competitive landscape thoroughly documented against Aider, Cursor, Kiro, OpenHands with official sources; MVP definition validated against dependency graph |
| Architecture | HIGH | Component build order corroborated by multiple production Go patterns; code examples are concrete and compilable; anti-patterns backed by specific failure modes |
| Pitfalls | HIGH | Primary claims backed by ICML 2025 academic research (MAST taxonomy), production post-mortems, and official documentation; failure rates are empirically cited |

**Overall confidence:** HIGH

### Gaps to Address

- **Prompt schema design for agent contracts:** The research recommends machine-readable schemas for agent input/output but does not specify the schema format (JSON Schema, Go structs, custom DSL). Decide during Phase 2 planning whether schemas are defined as Go structs, JSON Schema files, or embedded YAML — this decision affects the agent definition loading pattern.
- **Windows cross-platform testing strategy:** Atomic writes via os.Rename are not atomic on Windows. Research identifies this as a known issue but does not recommend an alternative write strategy for Windows. Decide during Phase 1 whether to support Windows at v1 or defer with explicit documentation.
- **Context compaction strategy for long sessions:** Pitfalls research flags 500+ message history as a performance trap requiring summarization and rolling windows, but does not specify the compaction algorithm. This needs a concrete design decision before Phase 3 context assembly work.
- **Checkpoint granularity definition:** Research recommends activity-level checkpointing (not superstep-level) but does not define what constitutes an "activity" within GopherMind's agent execution protocol. Define this precisely during Phase 2 agent contract design.

## Sources

### Primary (HIGH confidence)
- pkg.go.dev/github.com/anthropics/anthropic-sdk-go — v1.27.1 verified Mar 18, 2026
- pkg.go.dev/github.com/openai/openai-go — v3.29.0 verified Mar 17, 2026
- pkg.go.dev/google.golang.org/genai — v1.51.0 GA status confirmed Mar 18, 2026
- pkg.go.dev/github.com/spf13/cobra — v1.10.2 confirmed
- pkg.go.dev/github.com/spf13/viper — v1.21.0, Go 1.23+ required
- pkg.go.dev/golang.org/x/sync — official Go extended library
- arXiv 2503.13657 (ICML 2025 Spotlight) — MAST taxonomy; 41-86.7% multi-agent failure rate; 36.94% coordination failures
- kiro.dev/docs/specs/ — official Kiro spec-driven development documentation
- golang-standards/project-layout — standard Go project structure
- Michael Stapelberg — atomically writing files in Go (temp-file-rename pattern)
- Carolyn Van Slyck — Cobra + Viper flag binding pitfalls
- arXiv 2601.19106 — AST-based hallucination detection in LLM-generated code

### Secondary (MEDIUM confidence)
- dasroot.net/posts/2026/02 — AI workflow patterns in Go CLI tools
- dasroot.net/posts/2026/03 — building multi-model LLM gateway in Go
- diagrid.io — checkpointing vs. durable execution analysis
- fdrechsler.de — provider-agnostic agents: syntactic vs. semantic abstraction
- factory.ai — context window problem analysis
- comet.com — prompt drift in agentic systems
- portkey.ai — retries, fallbacks, and circuit breakers in LLM apps
- lushbinary.com — AI coding agents 2026 comparison
- mindstudio.ai — model routing cost reduction data (30-70% claim)

### Tertiary (LOW confidence)
- Community comparisons of Aider, Kiro, OpenHands feature sets — used for competitive analysis only; individual feature claims validated against official sources where possible

---
*Research completed: 2026-03-20*
*Ready for roadmap: yes*

# Architecture Research

**Domain:** Go CLI multi-agent LLM orchestration platform
**Researched:** 2026-03-20
**Confidence:** HIGH (corroborated by multiple production Go frameworks and community patterns)

## Standard Architecture

### System Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                          CLI Layer (cmd/)                           │
│  ┌──────────┐ ┌──────────┐ ┌────────┐ ┌────────┐ ┌─────────────┐  │
│  │  init    │ │  resume  │ │ status │ │ verify │ │  logs/costs │  │
│  └────┬─────┘ └────┬─────┘ └───┬────┘ └───┬────┘ └──────┬──────┘  │
└───────┴────────────┴───────────┴───────────┴─────────────┴─────────┘
                              │
┌─────────────────────────────▼───────────────────────────────────────┐
│                     Orchestration Layer (internal/orchestrator/)    │
│  ┌──────────────────────┐     ┌──────────────────────────────────┐  │
│  │   Session Manager    │     │    Dependency Graph Scheduler    │  │
│  │  (load/save/resume)  │     │  (DAG, parallel execution)       │  │
│  └──────────────────────┘     └──────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────▼───────────────────────────────────────┐
│                    Agent Runtime Layer (internal/agent/)            │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │
│  │Architect │ │ Planner  │ │ Coder    │ │ Reviewer │ │  Tester  │  │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘  │
│         [12+ specialized agents, each a definition + executor]      │
└─────────────────────────────────────────────────────────────────────┘
                              │
┌──────────────┬──────────────▼──────────────┬────────────────────────┐
│  Go Intel    │    LLM Provider Layer        │   State Layer          │
│  Layer       │   (internal/provider/)       │  (internal/state/)     │
│ (internal/   │  ┌────────┐ ┌────────────┐  │  ┌──────────────────┐  │
│  gointel/)   │  │Anthropic│ │  OpenAI    │  │  │  .planning/      │  │
│              │  └────────┘ └────────────┘  │  │  STATE.md        │  │
│ - mod detect │  ┌────────┐ ┌────────────┐  │  │  artifacts/      │  │
│ - pkg graph  │  │ Gemini │ │   Ollama   │  │  │  events.jsonl    │  │
│ - convention │  └────────┘ └────────────┘  │  └──────────────────┘  │
│   check      │  [unified Provider interface]│                        │
└──────────────┴─────────────────────────────┴────────────────────────┘
```

### Component Responsibilities

| Component | Responsibility | Typical Implementation |
|-----------|----------------|------------------------|
| CLI (cmd/) | Parse commands, validate flags, wire dependencies, call orchestrator | Cobra commands, one file per subcommand |
| Session Manager | Load/save session state, detect prior runs, enable resume | Reads/writes `.planning/STATE.md` and checkpoint files |
| Dependency Graph Scheduler | Build DAG of agent tasks, execute independent tasks in parallel | `sync.WaitGroup` + `errgroup`, topological sort |
| Agent Runtime | Execute agent protocol: load def → assemble context → select provider → execute → validate → write | Struct implementing `Agent` interface with `Run(ctx) error` |
| Agent Definition | Declarative spec: name, prompt, tools, success criteria, handoff rules | Embedded struct or YAML/JSON definition loaded at startup |
| Provider Interface | Unified `Complete(ctx, req) (resp, error)` over all LLM backends | Go interface + per-provider `struct` implementing it |
| Router | Select provider based on task type and routing rules | Config-driven rule table, returns `Provider` |
| Fallback Chain | Retry with backoff, failover to next provider on error | Wraps `Provider`, exponential backoff, error classification |
| Go Intelligence | Detect Go module, build package graph, check conventions | `go/packages` or shell-out to `go list`, AST analysis |
| State Persistence | Atomic writes of all planning artifacts, JSONL event log | `os.Rename` pattern (write temp → rename), append-only log |
| Cost Tracker | Accumulate token counts and costs per provider/agent/session | In-memory counter flushed to JSONL on each completion |
| Config | Load `config.json`, apply defaults, expose typed config struct | `encoding/json` unmarshal into config struct |

## Recommended Project Structure

```
gophermind/
├── cmd/
│   └── gophermind/
│       ├── main.go               # Entry point — wire deps, run root command
│       ├── root.go               # Root cobra command, global flags
│       ├── init.go               # `gophermind init` — questioning protocol
│       ├── resume.go             # `gophermind resume` — restore session
│       ├── status.go             # `gophermind status` — show current state
│       ├── verify.go             # `gophermind verify` — run verification gates
│       ├── logs.go               # `gophermind logs` — view event log
│       └── costs.go              # `gophermind costs` — show cost breakdown
├── internal/
│   ├── orchestrator/
│   │   ├── orchestrator.go       # Top-level coordinator, session lifecycle
│   │   ├── session.go            # Session load/save/resume logic
│   │   ├── graph.go              # DAG construction from agent dependencies
│   │   └── scheduler.go          # Parallel task execution with errgroup
│   ├── agent/
│   │   ├── agent.go              # Agent interface and base executor
│   │   ├── definition.go         # AgentDefinition struct (load from config)
│   │   ├── context.go            # Context assembly (gather inputs for prompt)
│   │   ├── validator.go          # Post-execution success criteria checking
│   │   ├── handoff.go            # Output routing to downstream agents
│   │   └── agents/               # One file per specialized agent
│   │       ├── architect.go
│   │       ├── planner.go
│   │       ├── coder.go
│   │       ├── reviewer.go
│   │       └── ...               # 12+ agents total
│   ├── provider/
│   │   ├── provider.go           # Provider interface and Request/Response types
│   │   ├── router.go             # Rule-based provider selection
│   │   ├── fallback.go           # Retry + backoff + failover chain
│   │   ├── health.go             # Provider availability monitoring
│   │   ├── anthropic/
│   │   │   └── anthropic.go      # Anthropic Messages API client
│   │   ├── openai/
│   │   │   └── openai.go         # OpenAI Chat Completions client
│   │   ├── gemini/
│   │   │   └── gemini.go         # Google Gemini client
│   │   └── ollama/
│   │       └── ollama.go         # Ollama local client
│   ├── gointel/
│   │   ├── module.go             # Go module detection and parsing
│   │   ├── packages.go           # Package graph via `go list`
│   │   └── conventions.go        # Convention checking (naming, errors, ctx)
│   ├── state/
│   │   ├── state.go              # STATE.md read/write
│   │   ├── atomic.go             # Atomic file write helper (write-temp-rename)
│   │   ├── events.go             # JSONL event log append
│   │   └── costs.go              # Cost accumulator and flush
│   └── config/
│       ├── config.go             # Config struct and defaults
│       └── load.go               # Load config.json, apply env overrides
├── config.json                   # Default configuration
├── go.mod
└── go.sum
```

### Structure Rationale

- **cmd/gophermind/:** All cobra command wiring lives here. Commands are thin — they parse flags, build dependencies, and call into `internal/`. No business logic.
- **internal/orchestrator/:** The only package that knows about the full session lifecycle. Owns the DAG and controls which agents run when.
- **internal/agent/:** Agents are composable units. The base `agent.go` defines the interface and common execution protocol. Each specialized agent in `agents/` provides its own definition (model, system prompt, tools, success criteria).
- **internal/provider/:** Pure adapter layer. `provider.go` defines the interface; each subdirectory is one backend. `router.go` and `fallback.go` are standalone — they compose providers, not extend them.
- **internal/gointel/:** Completely standalone from LLM concerns. Takes a directory path, returns Go-specific intelligence. Agents call it to assemble context.
- **internal/state/:** Owns all disk I/O for planning artifacts. Nothing else writes `.planning/` directly — all writes funnel through here, ensuring atomic guarantees.
- **internal/config/:** Loaded once at startup, passed down via dependency injection. No global config singleton.

## Architectural Patterns

### Pattern 1: Provider Interface with Adapter per Backend

**What:** Define a narrow `Provider` interface (`Complete`, `Stream`, `Health`) implemented by each LLM backend as a standalone struct. The rest of the system only sees the interface.

**When to use:** Always — this is the foundation of multi-provider support.

**Trade-offs:** Small additional indirection; massive benefit of swappable backends and testability via mock providers.

**Example:**
```go
// internal/provider/provider.go
type Request struct {
    SystemPrompt string
    Messages     []Message
    MaxTokens    int
    Temperature  float64
}

type Response struct {
    Content      string
    InputTokens  int
    OutputTokens int
    Model        string
}

type Provider interface {
    Complete(ctx context.Context, req Request) (Response, error)
    Name() string
    Health(ctx context.Context) error
}
```

### Pattern 2: Rule-Based Router with Fallback Chain

**What:** A `Router` selects a `Provider` by matching task type against a rule table from config. A `FallbackChain` wraps any `Provider` to add retry-with-backoff and secondary provider failover.

**When to use:** When you need predictable routing without dynamic/ML-based selection — rules are auditable and debuggable.

**Trade-offs:** Rigid rules require explicit maintenance when providers change; significantly simpler than dynamic routing.

**Example:**
```go
// internal/provider/router.go
type RoutingRule struct {
    TaskType string   // "architecture", "code_gen", "summarization"
    Primary  string   // provider name from config
    Fallback []string // ordered fallback chain
}

func (r *Router) Select(taskType string) Provider {
    rule := r.rules[taskType] // lookup by task type
    return NewFallbackChain(r.providers[rule.Primary], rule.Fallback...)
}
```

### Pattern 3: Agent Execution Protocol as Explicit Steps

**What:** Each agent follows the same five-step protocol: (1) load definition, (2) assemble context, (3) select provider via router, (4) execute + stream, (5) validate output against success criteria, (6) write artifacts, (7) signal handoff. Each step is a separate function with a defined input/output.

**When to use:** All agent execution — makes the flow inspectable, testable per-step, and resumable after interruption.

**Trade-offs:** More verbose than a single "run" function; necessary for auditability and debugging.

**Example:**
```go
// internal/agent/agent.go
type Agent interface {
    Definition() AgentDefinition
    Run(ctx context.Context, input AgentInput) (AgentOutput, error)
}

// base executor runs the protocol
func Execute(ctx context.Context, a Agent, input AgentInput, router *Router, state *State) error {
    def  := a.Definition()
    assembled := assembleContext(ctx, def, input, state)
    provider  := router.Select(def.TaskType)
    resp, err := provider.Complete(ctx, buildRequest(def, assembled))
    if err != nil { return err }
    if err := validate(def.SuccessCriteria, resp); err != nil { return err }
    return state.WriteArtifact(def.OutputPath, resp.Content)
}
```

### Pattern 4: DAG Scheduler with errgroup for Parallel Execution

**What:** Build a directed acyclic graph (DAG) from agent dependency declarations. Use `golang.org/x/sync/errgroup` to run independent agents concurrently; block each agent until its declared dependencies have completed.

**When to use:** Multi-agent phases where some agents are independent (e.g., multiple file generators that can run in parallel after planning).

**Trade-offs:** Complexity of dependency tracking; significant throughput improvement on multi-agent phases.

**Example:**
```go
// internal/orchestrator/scheduler.go
func (s *Scheduler) Run(ctx context.Context, tasks []Task) error {
    g, ctx := errgroup.WithContext(ctx)
    done := make(map[string]chan struct{})
    for _, t := range tasks {
        done[t.ID] = make(chan struct{})
    }
    for _, task := range tasks {
        t := task // capture
        g.Go(func() error {
            for _, dep := range t.DependsOn {
                <-done[dep] // wait for dependency
            }
            err := s.execute(ctx, t)
            close(done[t.ID]) // signal completion
            return err
        })
    }
    return g.Wait()
}
```

### Pattern 5: Atomic File Writes for Artifact Safety

**What:** All planning artifact writes go through a helper that writes to a temp file alongside the target, then calls `os.Rename` (atomic on POSIX). Partial writes never corrupt existing files.

**When to use:** Every write to `.planning/` — this is non-negotiable for a resumable system.

**Trade-offs:** Slight overhead; zero risk of corrupted state files.

**Example:**
```go
// internal/state/atomic.go
func WriteAtomic(path string, data []byte) error {
    dir  := filepath.Dir(path)
    tmp, err := os.CreateTemp(dir, ".tmp-*")
    if err != nil { return err }
    if _, err = tmp.Write(data); err != nil {
        os.Remove(tmp.Name())
        return err
    }
    tmp.Close()
    return os.Rename(tmp.Name(), path) // atomic on POSIX
}
```

## Data Flow

### Command Execution Flow

```
User: gophermind resume
        │
        ▼
cmd/resume.go          Parse flags, load config, create Orchestrator
        │
        ▼
orchestrator.Resume()  Read STATE.md → determine incomplete tasks
        │
        ▼
scheduler.Run()        Build DAG → launch goroutines per task wave
        │         ┌─────────────────────────────────────────────┐
        ▼         │ For each agent task (possibly concurrent):  │
agent.Execute()   │   1. assembleContext() ← state + gointel   │
        │         │   2. router.Select(taskType) → Provider     │
        │         │   3. provider.Complete(ctx, req)            │
        │         │   4. validate(successCriteria, response)    │
        │         │   5. state.WriteArtifact(path, content)     │
        │         │   6. state.AppendEvent(event)               │
        │         └─────────────────────────────────────────────┘
        │
        ▼
orchestrator       All tasks done → update STATE.md phase/status
        │
        ▼
cmd/resume.go      Print summary to stdout
```

### Provider Call Flow

```
agent.Execute()
        │
        ▼
router.Select(taskType)        Look up routing rule → primary provider name
        │
        ▼
FallbackChain.Complete()       Attempt primary provider
        │                           ├── Success → return Response
        │                           └── Error → classify error
        │                               ├── Transient (429, 503) → exponential backoff retry
        │                               └── Persistent → next provider in fallback list
        ▼
state.AppendEvent(ProviderCallEvent)    Log: provider, tokens, cost, latency, outcome
        │
        ▼
costs.Record(provider, tokens)         Accumulate cost counters for session
```

### State Write Flow

```
Agent produces artifact content
        │
        ▼
state.WriteArtifact(relativePath, content)
        │
        ▼
atomic.WriteAtomic(.planning/<path>)   Write temp → rename (atomic)
        │
        ▼
state.AppendEvent(ArtifactWrittenEvent)    Append to events.jsonl
        │
        ▼
state.UpdateSTATE()                    Rewrite STATE.md with current phase/tasks/risks
```

### Key Data Flows

1. **Init flow:** Wave-based questioning (8 waves) → answers assembled into project spec → spec written to `.planning/` → STATE.md initialized → orchestrator begins phase 1.
2. **Resume flow:** STATE.md parsed → incomplete tasks identified → DAG rebuilt from remaining tasks → scheduler resumes from first incomplete wave.
3. **Context assembly flow:** Agent definition declares which state files and Go intel it needs → `assembleContext()` reads those files and runs gointel queries → assembled context feeds into prompt construction.
4. **Cost tracking flow:** Every `provider.Complete()` call records tokens in the response → `costs.Record()` accumulates per-provider/per-agent → `gophermind costs` command reads the JSONL event log and aggregates.

## Component Build Order

The dependency graph between components determines the order in which they should be built:

```
1. internal/config        ← no internal deps
2. internal/state         ← depends on: config
3. internal/provider      ← depends on: config
4. internal/gointel       ← depends on: config
5. internal/agent         ← depends on: config, state, provider, gointel
6. internal/orchestrator  ← depends on: agent, state, config
7. cmd/gophermind         ← depends on: orchestrator, config
```

**Phase implications:**
- Phase 1 (Foundation): `config`, `state`, provider interface + one real provider (Anthropic)
- Phase 2 (Agent Runtime): `agent` base executor, 2-3 core agents (architect, planner, coder)
- Phase 3 (Orchestration): `orchestrator`, session, DAG scheduler
- Phase 4 (CLI): All `cmd/` commands wired to orchestrator
- Phase 5 (Go Intelligence): `gointel` integrated into agent context assembly
- Phase 6 (Full Provider Coverage): OpenAI, Gemini, Ollama, router, fallback chain
- Phase 7 (Remaining Agents): All 12+ specialized agents
- Phase 8 (Verification): Gates, cost tracking, health checks

## Scaling Considerations

This is a single-user local CLI tool. Scaling in the traditional sense does not apply. The relevant scaling concerns are:

| Scale | Architecture Adjustments |
|-------|--------------------------|
| Small project (< 20 files) | Single-phase execution, sequential agents acceptable |
| Medium project (20-200 files) | DAG parallelism needed; context window management becomes important |
| Large project (200+ files) | Chunked analysis passes; package-level rather than file-level context; streaming required |

### Scaling Priorities

1. **First bottleneck:** LLM context window limits — large codebases cannot be passed whole to an agent. Fix: `gointel` package graph enables selective context loading (only relevant packages).
2. **Second bottleneck:** Sequential agent execution latency — a 12-agent pipeline with 30s/agent is 6 minutes. Fix: DAG scheduler with parallel execution reduces wall time to the critical path length.

## Anti-Patterns

### Anti-Pattern 1: Global Provider or Config Singleton

**What people do:** Declare `var globalProvider provider.Provider` at package level and access it directly from agents.

**Why it's wrong:** Untestable (cannot inject mock), creates hidden coupling between packages, causes race conditions under parallel execution.

**Do this instead:** Pass `Provider` and `Config` through function arguments or a dependency struct. The orchestrator owns the wired graph; agents receive what they need.

### Anti-Pattern 2: Agents Calling State Directly

**What people do:** Have individual agent implementations write to `.planning/` themselves via `os.WriteFile`.

**Why it's wrong:** Bypasses atomic write guarantee, creates multiple code paths for writes, makes it impossible to enforce event logging consistently.

**Do this instead:** All disk writes flow through `internal/state`. Agents return their output; the executor (in `agent/agent.go`) calls `state.WriteArtifact`. Agents are pure functions of context → output.

### Anti-Pattern 3: Monolithic Agent with Branching Prompts

**What people do:** Build one large "do everything" agent that uses if/else prompt construction to handle architecture, coding, and review tasks.

**Why it's wrong:** Prompt quality degrades when a single agent tries to do too many things. Success criteria become impossible to validate. Hard to route to the right model.

**Do this instead:** 12+ specialized agents with narrow contracts. Each agent has one responsibility, one success criterion, and one model selection. Orchestrator composes them.

### Anti-Pattern 4: Chatty State Files (One File per Token)

**What people do:** Write a separate small file for every agent output, creating hundreds of tiny files in `.planning/`.

**Why it's wrong:** Hard to scan, hard to diff in git, creates `os.Open` overhead in context assembly.

**Do this instead:** Organize artifacts by phase and concern. Phase-level summary files plus per-agent outputs within phase directories. `STATE.md` is the single source of truth for current status.

### Anti-Pattern 5: Blocking on Provider Calls Without Context Cancellation

**What people do:** Call `provider.Complete(...)` without threading the caller's `context.Context` through, or without checking `ctx.Done()` during retries.

**Why it's wrong:** A cancelled CLI invocation (Ctrl-C) will not abort in-flight LLM calls. Retry loops become unkillable. Costs accumulate for abandoned sessions.

**Do this instead:** All provider methods accept `context.Context` as their first argument. Retry loops check `ctx.Err()` before each attempt. The CLI's root command sets a cancellable context wired to `os.Signal`.

## Integration Points

### External Services

| Service | Integration Pattern | Notes |
|---------|---------------------|-------|
| Anthropic API | HTTP client, `POST /v1/messages`, streaming SSE | API key from config; respect rate limits via backoff |
| OpenAI API | HTTP client, `POST /v1/chat/completions`, streaming | Same structure as Anthropic but different schema |
| Google Gemini | Official `google.golang.org/genai` SDK or HTTP | SDK preferred to handle auth and streaming |
| Ollama | HTTP client, `POST /api/chat`, local only | No API key; health check via `/api/tags` |

### Internal Boundaries

| Boundary | Communication | Notes |
|----------|---------------|-------|
| cmd → orchestrator | Direct function call (dependency injection) | Commands hold an `*Orchestrator` reference |
| orchestrator → agent | Interface call via scheduler | `scheduler.Run()` calls `agent.Execute()` per task |
| agent → provider | Interface call via router | `router.Select(taskType)` returns a `Provider` |
| agent → state | Function call via state package | `state.WriteArtifact()`, `state.AppendEvent()` |
| agent → gointel | Function call, returns structured data | `gointel.PackageGraph(dir)` returns typed result |
| provider → external | HTTP over TLS | Each provider client owns its own `http.Client` with timeout |

## Sources

- [CloudWego Eino — Go LLM framework architecture](https://github.com/cloudwego/eino)
- [GoAI — Clean multi-provider LLM client for Go](https://dev.to/dariubs/goai-a-clean-multi-provider-llm-client-for-go-27o5)
- [golang-standards/project-layout — Standard Go Project Layout](https://github.com/golang-standards/project-layout)
- [Go Modules official layout docs](https://go.dev/doc/modules/layout)
- [AI Workflow Patterns in Go: CLI Tools to Agents (Feb 2026)](https://dasroot.net/posts/2026/02/ai-workflow-patterns-go-cli-tools-agents/)
- [Go Microservices for AI/ML Orchestration Patterns](https://www.glukhov.org/app-architecture/integration-patterns/go-microservices-for-ai-ml-orchestration-patterns/)
- [Deep Dive into WaitGroup — Concurrent Task Orchestration in Go](https://dev.to/jones_charles_ad50858dbc0/deep-dive-into-waitgroup-mastering-concurrent-task-orchestration-in-go-ao)
- [Dependency Graphs and Orchestration in AI Agent Frameworks](https://www.gocodeo.com/post/dependency-graphs-orchestration-and-control-flows-in-ai-agent-frameworks)
- [Retries, fallbacks, and circuit breakers in LLM apps](https://portkey.ai/blog/retries-fallbacks-and-circuit-breakers-in-llm-apps/)
- [Atomically writing files in Go — Michael Stapelberg](https://michael.stapelberg.ch/posts/2017-01-28-golang_atomically_writing/)
- [Building a Production-Grade LLM Client in Go](https://www.ksred.com/building-a-production-ready-go-package-for-llm-integration/)
- [Spf13/cobra — CLI framework](https://github.com/spf13/cobra)
- [Concurrency in Go: Foundations, Patterns, and Agentic Architectures](https://aminmsv01.medium.com/concurrency-in-go-foundations-patterns-and-agentic-architectures-ee69ac212df9)
- [Building a Multi-Model LLM Gateway in Go (Mar 2026)](https://dasroot.net/posts/2026/03/building-multi-model-llm-gateway-go/)

---
*Architecture research for: Go CLI multi-agent LLM orchestration platform (GopherMind)*
*Researched: 2026-03-20*

# Stack Research

**Domain:** Go CLI multi-agent LLM orchestration platform
**Researched:** 2026-03-20
**Confidence:** HIGH (all core libraries verified via pkg.go.dev as of March 2026)

## Recommended Stack

### Core Technologies

| Technology | Version | Purpose | Why Recommended |
|------------|---------|---------|-----------------|
| Go | 1.23+ | Implementation language | Matches target audience, cross-platform single binary, strong stdlib concurrency primitives, explicit error handling aligns with GopherMind's auditability requirements |
| github.com/spf13/cobra | v1.10.2 | CLI command structure and flag parsing | De facto standard for Go CLIs (Kubernetes, Hugo, GitHub CLI). Provides subcommands, persistent flags, shell completions, help generation. Zero magic. |
| github.com/spf13/viper | v1.21.0 | Configuration management (config.json, env vars, flags) | Natural Cobra companion. Multi-source config with precedence chain: flags > env > config.json > defaults. Requires Go 1.23. |
| log/slog (stdlib) | Go 1.21+ | Structured JSON/JSONL logging | Zero external dependency. JSONHandler produces JSONL events. Concurrent-safe by design. Idiomatic since 1.21 — use for all internal logging. |
| golang.org/x/sync | v0.x (latest) | errgroup + weighted semaphore for parallel agent execution | Official Go extended sync library. errgroup gives context-canceling goroutine groups. Weighted semaphore bounds concurrent provider calls. The correct tool for GopherMind's dependency-graph agent coordination. |

### LLM Provider SDKs

| Library | Version | Provider | Why This One |
|---------|---------|----------|-------------|
| github.com/anthropics/anthropic-sdk-go | v1.27.1 | Anthropic / Claude | Official Anthropic SDK. v1+ stable. Streaming, tool use, batching, error types, token counting. Published Mar 18, 2026. |
| github.com/openai/openai-go/v3 | v3.29.0 | OpenAI | Official OpenAI SDK. v3 series is current. Chat completions, streaming, tool calls. Go 1.22+. Published Mar 17, 2026. |
| google.golang.org/genai | v1.51+ | Google Gemini | Official Google Gen AI SDK (GA since May 2025). Replaces deprecated generative-ai-go. Supports both Gemini Developer API and Vertex AI. Apache-2.0. Published Mar 18, 2026. |
| github.com/ollama/ollama/api | v0.18.2 | Ollama (local) | Official Ollama client — embedded in the Ollama project itself. Typed client for all REST endpoints. Pre-v1 but actively maintained alongside Ollama releases. |

### Supporting Libraries

| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| github.com/cenkalti/backoff/v5 | v5.x | Exponential backoff for provider failover | Provider call retries with jitter. Use for all LLM API calls — prevents thundering-herd on rate limit errors. v5 requires Go 1.23 (matches our baseline). |
| github.com/google/renameio | v1.x | Atomic file writes (temp → rename) | All .planning/ artifact writes. Write to temp in same directory, then os.Rename — either full write or nothing. Prevents corrupt state on interrupt. |

### Development Tools

| Tool | Purpose | Notes |
|------|---------|-------|
| goreleaser | Cross-platform binary release (macOS, Linux, Windows) | Single config builds all targets. Use with GitHub Actions for distribution. |
| golangci-lint | Linting and static analysis | Run errcheck, staticcheck, govet, revive at minimum. Catches unhandled errors in provider callbacks. |
| go test -race | Race condition detection | Required for all concurrent agent execution tests. Run in CI. |
| go tool cover | Coverage reporting | Verification gate: GopherMind enforces its own coverage thresholds. Dogfood it. |

## Installation

```bash
# Initialize module
go mod init gophermind

# CLI framework
go get github.com/spf13/cobra@v1.10.2
go get github.com/spf13/viper@v1.21.0

# LLM provider SDKs
go get github.com/anthropics/anthropic-sdk-go@latest
go get github.com/openai/openai-go/v3@latest
go get google.golang.org/genai@latest
go get github.com/ollama/ollama/api@latest

# Concurrency and reliability
go get golang.org/x/sync@latest
go get github.com/cenkalti/backoff/v5@latest

# Atomic file writes
go get github.com/google/renameio@latest
```

## Alternatives Considered

| Recommended | Alternative | When to Use Alternative |
|-------------|-------------|-------------------------|
| github.com/spf13/cobra | urfave/cli v2 | Only if you prefer functional options over struct-based commands. Cobra's annotation-based shell completion and documentation generation are better for a tool like GopherMind. |
| log/slog (stdlib) | github.com/rs/zerolog | Only if benchmarks show slog is a bottleneck (unlikely for a CLI tool). zerolog is ~1.3x faster but adds a dependency. slog is the idiomatic 2025 choice for new Go projects. |
| log/slog (stdlib) | github.com/uber-go/zap | Same rationale as zerolog — zap adds complexity and external dependency with marginal gain for CLI I/O rates. |
| github.com/openai/openai-go/v3 | github.com/sashabaranov/go-openai | sashabaranov is community-maintained and widely used, but openai/openai-go is the official SDK now. Use official for forward compatibility with OpenAI API changes. |
| google.golang.org/genai | github.com/google/generative-ai-go | generative-ai-go is deprecated. Support ends November 30, 2025. Do not use. |
| golang.org/x/sync (errgroup + semaphore) | Custom goroutine pool | Custom pools are fine for simple cases but errgroup handles error propagation and context cancellation correctly — critical for agent fanout patterns. |
| github.com/cenkalti/backoff/v5 | github.com/avast/retry-go | Both are solid. backoff v5 aligns with the Google-originated exponential backoff spec and is more commonly used in production Go services. Either works. |
| Pure DI (manual constructors) | google/wire or uber-go/fx | For a CLI tool of this size, manual constructor injection is simpler to read and debug. Wire/Fx add code generation or reflection overhead that isn't warranted for a single-binary CLI. |

## What NOT to Use

| Avoid | Why | Use Instead |
|-------|-----|-------------|
| github.com/google/generative-ai-go | Deprecated. Google ended support November 30, 2025. Will not receive security patches. | google.golang.org/genai |
| github.com/liushuangls/go-anthropic | Community fork — not official Anthropic. Will lag official API changes. | github.com/anthropics/anthropic-sdk-go |
| github.com/sirupsen/logrus | Maintenance mode. Author recommends migrating to slog. Mutex-per-write design predates modern Go idioms. | log/slog |
| Database (SQLite, bbolt, etc.) | Project explicitly requires file-based .planning/ persistence — no external DB. SQLite adds CGo dependency breaking cross-compilation. | Plain file I/O with atomic writes via renameio |
| github.com/cloudwego/eino | Heavyweight LLM framework with its own abstractions. Adds 35+ dependencies and imposes opinionated graph execution model that conflicts with GopherMind's explicit agent contract design. | Thin Provider interface wrapping official SDKs directly |
| gRPC / protobuf | No inter-service communication needed. Single-binary CLI calling external HTTP APIs. gRPC would add complexity with zero benefit. | net/http (stdlib) for all provider calls, handled by provider SDKs |
| Uber Fx / Google Wire | DI containers add reflection overhead and generated code complexity that is not justified for a CLI tool. | Manual constructor injection |

## Stack Patterns by Variant

**For the Provider interface (unified LLM abstraction):**
- Define a single `Provider` interface: `Complete(ctx, messages, opts) (Response, error)` and `Stream(ctx, messages, opts) (<-chan Token, error)`
- Each provider SDK wraps into a thin struct implementing this interface
- Rule-based router selects provider by task tier, not dynamically
- Because: explicit routing is auditable; GopherMind's stated design goal is predictable, debuggable behavior

**For parallel agent execution:**
- Use `errgroup.WithContext` for the agent fan-out
- Use `golang.org/x/sync/semaphore` weighted semaphore to cap concurrent provider calls (e.g., max 5 simultaneous LLM calls)
- Dependency graph: topological sort of agent dependencies, execute each wave with errgroup
- Because: errgroup propagates first error and cancels remaining agents — correct behavior for a verification-gated pipeline

**For file-based state (STATE.md, JSONL events, artifact files):**
- All writes use atomic pattern: `renameio.WriteFile(path, data, perm)`
- Reads use `os.ReadFile` — no locking needed since writes are atomic
- JSONL event log: open with `os.OpenFile(O_APPEND|O_WRONLY|O_CREATE)`, protected by a single `sync.Mutex` in the event logger
- Because: atomic writes prevent half-written artifacts on SIGINT; append+mutex is the standard JSONL write pattern

**For CLI configuration layering:**
- Viper binds: flags (cobra PersistentPreRun) > env vars (GOPHERMIND_*) > config.json > defaults
- Config file location: `~/.config/gophermind/config.json` or `.gophermind/config.json` in project root
- Because: this is the standard Cobra+Viper precedence pattern used by kubectl, helm, and most production Go CLIs

## Version Compatibility

| Package | Compatible With | Notes |
|---------|-----------------|-------|
| github.com/spf13/viper v1.21.0 | Go 1.23+ | Viper v1.21 requires Go 1.23 minimum — sets our Go floor |
| github.com/cenkalti/backoff/v5 | Go 1.23+ | v5 also requires Go 1.23 — consistent with viper constraint |
| github.com/anthropics/anthropic-sdk-go v1.27.1 | Go 1.18+ | No conflict with Go 1.23 baseline |
| github.com/openai/openai-go/v3 v3.29.0 | Go 1.22+ | No conflict with Go 1.23 baseline |
| google.golang.org/genai v1.51+ | Go 1.21+ | No conflict with Go 1.23 baseline |
| github.com/ollama/ollama/api v0.18.2 | Go 1.22+ | Pre-v1; pin to minor version in go.sum, watch for breaking changes |

**Effective Go minimum: 1.23** (driven by viper v1.21 and backoff v5)

## Sources

- `pkg.go.dev/github.com/anthropics/anthropic-sdk-go` — v1.27.1 verified Mar 18, 2026 (HIGH confidence)
- `pkg.go.dev/github.com/openai/openai-go` + releases page — v3.29.0 verified Mar 17, 2026 (HIGH confidence)
- `pkg.go.dev/google.golang.org/genai` — v1.51.0 verified Mar 18, 2026, GA status confirmed (HIGH confidence)
- `pkg.go.dev/github.com/ollama/ollama/api` — v0.18.2 verified Mar 18, 2026 (HIGH confidence)
- `pkg.go.dev/github.com/spf13/cobra` — v1.10.2 Dec 2025 (HIGH confidence)
- `pkg.go.dev/github.com/spf13/viper` — v1.21.0 Sep 2025, Go 1.23+ required (HIGH confidence)
- `pkg.go.dev/golang.org/x/sync/errgroup` + `semaphore` — official Go extended library (HIGH confidence)
- `github.com/cenkalti/backoff` — v5 requires Go 1.23, confirmed via pkg.go.dev (HIGH confidence)
- `github.com/google/renameio` — pkg.go.dev + Michael Stapelberg's original post on atomic Go file writes (MEDIUM confidence — widely used pattern, library lightly maintained but pattern is stable)
- WebSearch: "Google generative-ai-go deprecated" — confirmed deprecated, support ends Nov 30, 2025 (HIGH confidence, multiple sources)
- WebSearch: "Go slog vs zerolog production 2025" — slog recommended for new projects, zerolog for extreme perf (HIGH confidence, multiple sources agree)

---
*Stack research for: GopherMind — Go multi-agent LLM orchestration platform*
*Researched: 2026-03-20*

# Feature Research

**Domain:** AI-powered spec-driven Go development platform / LLM orchestration CLI
**Researched:** 2026-03-20
**Confidence:** HIGH (competitive landscape well-documented; GopherMind differentiators validated against Kiro, OpenHands, Aider, Claude Code)

---

## Feature Landscape

### Table Stakes (Users Expect These)

Features users assume exist. Missing these = product feels incomplete.

| Feature | Why Expected | Complexity | Notes |
|---------|--------------|------------|-------|
| Multi-file codebase understanding | Every serious AI coding tool (Aider, Cursor, OpenHands) builds a repo map; users expect the agent to understand the whole project, not just one file | MEDIUM | Go-specific: parse `go.mod`, import graph, package layout |
| Streaming output to terminal | All CLI tools stream LLM output; waiting silently for results feels broken | LOW | Use `io.Writer` streaming from provider; avoid buffering entire responses |
| Git-aware operations | Aider auto-commits with descriptive messages; users expect AI changes to be committed and attributable | MEDIUM | Wrap `git` via `os/exec`; stage + commit after each agent write |
| Multi-provider LLM support | Aider, Cursor, Kiro all support multiple models; users expect to use their preferred provider or switch for cost | HIGH | Anthropic, OpenAI required for v1; Google/Ollama stretch goals |
| Cost tracking per session | API costs are real; every serious tool either shows usage or is expected to | MEDIUM | Token accounting per provider + per agent call; session totals |
| Project initialization flow | Every tool has an `init` or onboarding command; users expect guided setup, not manual config editing | MEDIUM | 8-wave questioning protocol already planned; this is the expected entry point |
| Resumable sessions | Claude Code Tasks, LangGraph checkpointing, and OpenHands all support resumability; losing context mid-session is unacceptable | HIGH | File-based state in `.planning/` gives this "for free" if maintained rigorously |
| Structured output artifacts | Kiro produces `requirements.md`, `design.md`, `tasks.md`; OpenHands produces `PLAN.md`; users expect readable, persistent artifacts — not ephemeral chat | MEDIUM | Planning directory conventions already defined in PROJECT.md |
| Error recovery and retry | Providers fail; users expect transparent retry with backoff, not silent hangs | MEDIUM | Exponential backoff + provider fallback chains already in requirements |
| Status and progress visibility | `status` command expected by any CLI tool managing long-running workflows | LOW | Read from STATE.md; display current phase, tasks, open risks |

---

### Differentiators (Competitive Advantage)

Features that set the product apart. Not required by the market, but high value for GopherMind's target user.

| Feature | Value Proposition | Complexity | Notes |
|---------|-------------------|------------|-------|
| Spec-first lifecycle management | Kiro introduced spec-driven development but is IDE-only and AWS-centric; GopherMind owns this as a pure CLI with no IDE dependency — the only spec-driven CLI tool targeting Go devs | HIGH | Three-phase flow: spec generation → technical plan → phased implementation; each phase produces durable artifacts |
| Specialized agent contracts with explicit success criteria | All current tools use a single general-purpose agent or chat; GopherMind's 12+ specialized agents with defined contracts and handoff rules prevent vague outputs — a direct response to "AI that produces garbage you can't verify" | HIGH | Each agent has: input preconditions, output postconditions, success criteria, failure modes; orchestrator validates handoffs |
| Rule-based task routing (right model for right job) | Most tools use one model for everything; routing architecture vs. summarization vs. code-gen jobs to appropriately-priced models achieves 30-70% cost reduction (industry data) without sacrificing quality | HIGH | Routing table in config.json; architecture tasks → Claude Opus; summarization → Haiku/Flash; code gen → Sonnet |
| Go intelligence layer | No current tool deeply understands Go idioms: `go.mod` parsing, package graph analysis, convention enforcement (error wrapping, context propagation, structured logging patterns) | HIGH | `go/ast`, `go/packages`, `golang.org/x/tools/go/analysis` as foundations; internal knowledge of Go project layouts |
| Verification gates between phases | No competitor enforces quality gates before advancing phases; GopherMind blocks phase transitions on coverage checks, consistency checks, alignment checks — prevents "half-built" codebases | HIGH | Gate config per phase; coverage threshold, interface completeness, spec alignment checks |
| Auditable JSONL event log | Every provider call, every token spent, every agent decision logged in structured JSONL; users can query history, debug failures, replay events — no competitor offers this level of auditability | MEDIUM | Events, costs, and provider calls as separate JSONL streams; parseable by `jq` or any log tooling |
| Parallel agent execution with dependency graph | OpenHands and Claude Code show parallel agents are valuable but ad-hoc; GopherMind makes the dependency graph explicit and coordinates parallel execution deterministically | HIGH | DAG-based task graph; independent agents run in goroutines; dependent agents block on channel signals |
| Checkpoint + atomic file writes | Session crashes are common during long agentic runs; atomic writes (temp → rename) + explicit checkpoint markers mean zero partial-write corruption | MEDIUM | `os.Rename` atomicity on POSIX; checkpoint markers in STATE.md |
| Wave-based elicitation protocol | Generic tools ask vague "what do you want to build?" questions; 8-wave progressive questioning produces complete, unambiguous specs before a single line of code is written | MEDIUM | Wave progression: domain → constraints → architecture → data → integrations → quality → deployment → review |
| Provider health monitoring | Tools fail silently when providers are degraded; GopherMind monitors provider availability and reroutes proactively — not reactively | MEDIUM | Lightweight health check goroutine; circuit breaker pattern per provider |

---

### Anti-Features (Commonly Requested, Often Problematic)

Features that seem good but create problems. Build these and regret it.

| Feature | Why Requested | Why Problematic | Alternative |
|---------|---------------|-----------------|-------------|
| Web UI / dashboard | "Easier to visualize project state and interact with" | Doubles scope, breaks CLI-first philosophy, requires frontend stack, authentication, sessions — a multi-month detour from v1 | Rich terminal output (`lipgloss`, `bubbletea`) achieves 80% of the visual value at 5% of the cost; defer web UI to post-v1 |
| Real-time collaboration / multi-user | "Teams want to share AI sessions" | Concurrent writes to `.planning/` need locking, conflict resolution, presence awareness — a distributed systems problem disguised as a feature | Single-user v1; git-based collaboration (`.planning/` is committed) gives async teamwork without complexity |
| Chat / conversational interface | "I want to just chat with the AI about my code" | Chat is Cursor/Copilot's game; GopherMind wins on structured, verifiable outputs — not chat. Adding chat trains users to expect vague responses and undermines the spec-driven value prop | `ask` mode for one-off questions is fine; full conversational loop is an anti-pattern for this product |
| Plugin / extension API | "Let the community build integrations" | Premature extensibility is the root of all evil in tooling; public APIs become permanent contracts before the internals are stable | Internal architecture designed for extension; expose plugin API only after v1 proves out the contracts |
| LLM fine-tuning / model hosting | "Host our own tuned model for Go" | Operating ML infrastructure is a separate business; distraction from the dev tool | Stay provider-agnostic; benefit from frontier model improvements for free |
| Cloud sync / SaaS mode | "Sync planning state across machines" | Requires auth, storage, encryption-at-rest, billing — a product pivot, not a feature | Git push `.planning/`; it's already a directory. Users already know how to sync git repos. |
| Auto-approve all agent actions | "I want full automation with no confirmations" | Silent automation destroys trust when wrong; in code generation context this produces unreviewed commits and cascading mistakes | Default to confirmation gates at phase transitions; allow `--non-interactive` flag for CI/scripted use only |
| IDE integration (LSP, extension) | "Make it work inside VS Code / Cursor" | Deep IDE integration requires per-IDE SDKs, extension lifecycle management, different UX paradigm — all orthogonal to CLI | CLI works inside any terminal including those inside IDEs; users invoke it from the integrated terminal |

---

## Feature Dependencies

```
[Project Initialization / Wave-Based Elicitation]
    └──produces──> [Spec Artifacts (.planning/)]
                       └──requires──> [Agent Execution Protocol]
                                          └──requires──> [Multi-Provider LLM Support]
                                          └──requires──> [Rule-Based Task Routing]
                                          └──requires──> [Specialized Agent Contracts]

[Parallel Agent Execution]
    └──requires──> [Dependency Graph Coordination]
    └──requires──> [File-Based State Persistence]

[Verification Gates]
    └──requires──> [Go Intelligence Layer]
    └──requires──> [Agent Execution Protocol]
    └──requires──> [File-Based State Persistence]

[Resumability / Checkpoint]
    └──requires──> [File-Based State Persistence]
    └──requires──> [Atomic File Writes]

[Cost Tracking]
    └──requires──> [Multi-Provider LLM Support]
    └──enhances──> [Rule-Based Task Routing]  (cost data informs routing decisions)

[Provider Health Monitoring]
    └──enhances──> [Multi-Provider LLM Support]
    └──requires──> [Fallback Chains]

[Auditable JSONL Event Log]
    └──requires──> [Agent Execution Protocol]
    └──requires──> [Cost Tracking]

[Go Intelligence Layer]
    └──enhances──> [Specialized Agent Contracts]  (Go-aware agents produce better outputs)
    └──enhances──> [Verification Gates]  (Go-specific checks: coverage, conventions)
```

### Dependency Notes

- **Spec Artifacts require Wave-Based Elicitation:** The 8-wave questioning protocol produces the planning artifacts that all downstream agents consume. This is the root of the dependency tree — nothing meaningful runs before `gophermind init` completes.
- **Agent Execution Protocol requires Multi-Provider LLM Support:** Agents cannot execute without a functioning provider layer. Provider layer must be built and tested before any agent logic.
- **Verification Gates require Go Intelligence:** Gates that check Go conventions (error handling, context propagation, package layout) need the Go intelligence layer to be operational first. Generic coverage checks can run earlier.
- **Cost Tracking enhances Task Routing:** Once cost data is collected per agent call, the routing rules can be validated and tuned. Routing can launch with static rules; cost data makes it smarter over time.
- **Parallel Execution requires Dependency Graph:** Goroutines without an explicit graph lead to race conditions. Build the graph coordinator before enabling parallel agent runs.

---

## MVP Definition

### Launch With (v1)

Minimum viable product — what's needed to validate the spec-driven, agent-orchestrated approach.

- [ ] Multi-provider LLM support (Anthropic + OpenAI) — without providers, nothing works
- [ ] Wave-based project initialization (8 waves) — this is the spec-driven entry point; validates the core thesis
- [ ] File-based state persistence in `.planning/` — required for all resumability and agent handoffs
- [ ] Specialized agent execution protocol (load → assemble context → execute → validate → write → handoff) — the core differentiator
- [ ] At minimum 6 agents (Architect, Planner, Coder, Reviewer, Tester, Verifier) — covers the full lifecycle minimally
- [ ] Rule-based task routing (static table) — directs different jobs to appropriate models; controls costs day one
- [ ] Verification gates at phase transitions — without gates, the "verifiable" part of the value prop is missing
- [ ] Cost tracking per session — users need visibility into spend before they'll commit to the tool
- [ ] Resumable sessions via checkpoint markers — long runs will be interrupted; this must work before users trust it
- [ ] Structured JSONL event logging — audit trail is part of the core value proposition
- [ ] `init`, `status`, `resume`, `verify`, `logs`, `costs` CLI commands — minimum command set for a usable workflow
- [ ] Atomic file writes — correctness requirement; not optional

### Add After Validation (v1.x)

Features to add once core workflow is proven.

- [ ] Go intelligence layer (module graph, convention checks) — validates that Go-specific value is real; adds after first users report need for it
- [ ] Parallel agent execution with dependency graph — adds throughput; defer until sequential execution is solid and users request speed improvement
- [ ] Provider health monitoring and circuit breakers — add when provider reliability becomes a real user complaint
- [ ] Remaining 6+ specialized agents — add as workflows expand beyond core lifecycle
- [ ] Ollama / local model support — add after primary provider integrations are solid; serves privacy-first users
- [ ] Google Gemini support — add after Anthropic + OpenAI are stable; third provider has diminishing returns until first two work well

### Future Consideration (v2+)

Features to defer until product-market fit is established.

- [ ] Web UI — significant investment; validate CLI value first
- [ ] Cloud sync — requires auth and storage infrastructure; Git is sufficient for v1 users
- [ ] Plugin / extension API — stabilize internal contracts before making them public
- [ ] Non-Go repository support — Go-first focus is the competitive moat; expand only after Go market is proven
- [ ] Real-time collaboration — single-user tool is the correct v1 scope

---

## Feature Prioritization Matrix

| Feature | User Value | Implementation Cost | Priority |
|---------|------------|---------------------|----------|
| Multi-provider LLM support | HIGH | HIGH | P1 |
| Wave-based initialization | HIGH | MEDIUM | P1 |
| File-based state persistence | HIGH | LOW | P1 |
| Agent execution protocol | HIGH | HIGH | P1 |
| Verification gates | HIGH | HIGH | P1 |
| Cost tracking | HIGH | MEDIUM | P1 |
| Resumable sessions | HIGH | MEDIUM | P1 |
| JSONL event logging | HIGH | LOW | P1 |
| CLI command set | HIGH | LOW | P1 |
| Atomic file writes | HIGH | LOW | P1 |
| Rule-based task routing | HIGH | MEDIUM | P1 |
| Specialized agent contracts (6 core) | HIGH | HIGH | P1 |
| Go intelligence layer | HIGH | HIGH | P2 |
| Parallel agent execution | MEDIUM | HIGH | P2 |
| Provider health monitoring | MEDIUM | MEDIUM | P2 |
| Extended agent set (12+) | MEDIUM | HIGH | P2 |
| Ollama / local model support | MEDIUM | MEDIUM | P2 |
| Google Gemini support | LOW | MEDIUM | P2 |
| Web UI | HIGH | HIGH | P3 |
| Cloud sync | MEDIUM | HIGH | P3 |
| Plugin API | LOW | HIGH | P3 |

**Priority key:**
- P1: Must have for launch
- P2: Should have, add when possible
- P3: Nice to have, future consideration

---

## Competitor Feature Analysis

| Feature | Aider | Cursor | OpenHands | Kiro | GopherMind Approach |
|---------|-------|--------|-----------|------|---------------------|
| Spec / requirements generation | No (architect mode is conversational, not structured) | No | Planning agent (March 2026 addition) | Yes — requirements.md, design.md, tasks.md | Yes — wave-based elicitation produces structured spec artifacts |
| Multi-provider LLM | Yes (100+ via LiteLLM) | Yes (GPT-5, Claude Opus, Gemini) | Yes (any OpenAI-compatible) | Limited (Claude + Auto mix) | Yes (Anthropic + OpenAI v1; Gemini + Ollama v1.x) |
| Task routing by job type | No — single model | Partially (user selects per chat) | No | No | Yes — explicit routing table by agent role |
| Cost tracking | Basic (token counts) | No (subscription hides cost) | No | No | Yes — per agent, per provider, per session |
| Persistent planning artifacts | No — ephemeral chat | No | PLAN.md only | Yes — specs directory | Yes — full .planning/ directory with STATE.md |
| Resumable sessions | Partial (git history) | No | Partial | Partial | Yes — explicit checkpoint + STATE.md |
| Specialized agents with contracts | No — single agent | No | No | No | Yes — 12+ agents with defined contracts and handoff rules |
| Verification gates | No | No | No | No | Yes — phase gates with coverage, consistency, alignment checks |
| Go-specific intelligence | No | No | No | No | Yes — module graph, convention checks, Go idiom enforcement |
| Parallel agent execution | No | Background agents (beta) | Basic | No | Yes (v1.x) — DAG-based goroutine coordination |
| CLI-first | Yes | No (IDE) | No (web UI) | Partially (IDE + CLI) | Yes — terminal-native |
| Local / offline capable | Partial (needs API) | No | No | No | Yes (Ollama support in v1.x) |
| Auditable event log | No | No | No | No | Yes — structured JSONL events, costs, provider calls |

---

## Sources

- [Aider features overview](https://aider.chat/) — official site; HIGH confidence
- [Aider GitHub repository](https://github.com/Aider-AI/aider) — source of truth for capabilities; HIGH confidence
- [Kiro spec-driven development docs](https://kiro.dev/docs/specs/) — official Kiro docs; HIGH confidence
- [Kiro hooks documentation](https://kiro.dev/docs/hooks/) — official; HIGH confidence
- [Introducing Kiro blog post](https://kiro.dev/blog/introducing-kiro/) — canonical feature announcement; HIGH confidence
- [OpenHands product update March 2026](https://openhands.dev/blog/openhands-product-update---march-2026) — official; HIGH confidence
- [OpenHands vs SWE-Agent comparison](https://localaimaster.com/blog/openhands-vs-swe-agent) — community analysis; MEDIUM confidence
- [OpenHands Software Agent SDK paper](https://arxiv.org/html/2511.03690v1) — academic/technical; HIGH confidence
- [Spec-driven development with AI — GitHub Blog](https://github.blog/ai-and-ml/generative-ai/spec-driven-development-with-ai-get-started-with-a-new-open-source-toolkit/) — GitHub official; HIGH confidence
- [Thoughtworks on spec-driven development 2025](https://www.thoughtworks.com/en-us/insights/blog/agile-engineering-practices/spec-driven-development-unpacking-2025-new-engineering-practices) — industry analysis; MEDIUM confidence
- [AI coding agents 2026 comparison — Lushbinary](https://lushbinary.com/blog/ai-coding-agents-comparison-cursor-windsurf-claude-copilot-kiro-2026/) — multi-tool feature comparison; MEDIUM confidence
- [Multi-provider LLM cost reduction data — MindStudio](https://www.mindstudio.ai/blog/what-is-ai-model-router-optimize-cost-llm-providers) — routing ROI claims; MEDIUM confidence
- [Parallel agent patterns — Google ADK docs](https://google.github.io/adk-docs/agents/workflow-agents/parallel-agents/) — official Google ADK; HIGH confidence
- [Claude Code Tasks persistence — DEV Community](https://dev.to/simone_callegari_1f56a902/claude-code-new-tasks-persisting-between-sessions-and-swarms-of-agents-against-context-rot-5dan) — community report on Claude Code internals; MEDIUM confidence
- [Quality gates in agentic AI coding — CodeScene](https://codescene.com/blog/agentic-ai-coding-best-practice-patterns-for-speed-with-quality) — industry practice analysis; MEDIUM confidence
- [Kiro vs Claude Code comparison — Morph](https://www.morphllm.com/comparisons/kiro-vs-claude-code) — feature comparison; MEDIUM confidence

---

*Feature research for: GopherMind — spec-driven Go development platform*
*Researched: 2026-03-20*

# Pitfalls Research

**Domain:** Multi-agent LLM orchestration platform, provider abstraction, Go CLI development tool
**Researched:** 2026-03-20
**Confidence:** HIGH (primary claims verified against multiple sources including academic research, official docs, and post-mortems)

---

## Critical Pitfalls

### Pitfall 1: Treating Provider Abstraction as Purely Syntactic

**What goes wrong:**
You build a unified Provider interface that maps OpenAI, Anthropic, and Google to a common schema. It works in happy-path tests. In production, tool-calling fails intermittently, streaming finish-reasons behave differently across providers, and identical prompts produce divergent outputs. Models below reliability thresholds break entire agent graphs rather than degrading gracefully.

**Why it happens:**
Adapter patterns solve the syntactic translation problem (tool call schema, message format, streaming event structure) but not the semantic problem. OpenAI expects tool calls in a `tools` array; Anthropic uses `tool_use` content blocks; Google uses `function_declarations`. After normalization, tool-call enforcement (`tool_choice`), parallel tool-call execution, and streaming finish-reason semantics remain provider-specific. Behavioral differences across model families compound this — the same instruction produces different behavior from claude-3-5-sonnet vs gpt-4o.

**How to avoid:**
Design three separate layers: (1) syntactic adapter per provider, (2) behavioral contract tests that run against every provider asserting output structure, not just API success, and (3) a routing layer that encodes known behavioral constraints per provider. Never assume a prompt optimized for one model family is portable. Budget for per-provider prompt tuning from the start. Accept that the interface leaks at edge cases — document where it leaks rather than hiding it.

**Warning signs:**
- Agent steps succeed in tests against one provider but fail against another
- Streaming response handling has a large conditional block per provider
- A provider upgrade silently changes tool-call behavior without tests catching it
- Provider interface methods return `interface{}` or untyped maps to handle divergent response shapes

**Phase to address:**
Phase 1 (Provider Layer). Build behavioral contract tests alongside the interface definition. Do not defer until integration testing.

---

### Pitfall 2: Coordination Failures from Underspecified Agent Contracts

**What goes wrong:**
Research shows 41-86.7% of multi-agent systems fail in production. Coordination failures account for 36.94% of all failures: agents duplicate work, talk past each other, or forget their own responsibilities. One misinterpreted handoff message early in a pipeline cascades through subsequent agents, producing confident but wrong final output.

**Why it happens:**
Agent contracts that describe what an agent does but not what constitutes a valid handoff, what the receiving agent expects, or what to do on partial failure are insufficient. In multi-step pipelines, locally reasonable decisions are globally incoherent when agents cannot see the full dependency graph. 79% of failures originate from specification and coordination issues, not technical implementation.

**How to avoid:**
Every agent definition must include: explicit input schema (what it receives), explicit output schema (what it emits), success criteria (how to validate output before handoff), and failure behavior (what the calling agent should do if output is invalid). Treat agent contracts as typed interfaces, not prose descriptions. Validate at every handoff, not just at the end. Build a dependency graph that is loaded and validated at startup — agents must not make implicit assumptions about execution order.

**Warning signs:**
- Agent definitions describe behavior in prose without structured input/output schemas
- Handoff validation only happens at the final output step
- Agent failures surface as unexpected output rather than explicit errors
- Adding a new agent requires reading multiple other agents' code to understand what they emit

**Phase to address:**
Phase 2 (Agent Runtime). Define and validate contracts before implementing agent logic.

---

### Pitfall 3: Context Window Exhaustion Causing Silent Failures

**What goes wrong:**
A 50-step workflow with 20K tokens per call consumes 1 million tokens total. Context windows fill silently — earlier context is dropped without error, agents continue executing with incomplete information, and output looks plausible but is wrong. This does not surface as a "too many tokens" error; it surfaces as confusing product behavior that is hard to reproduce.

**Why it happens:**
Developers assume more context equals better results and stuff code files, history, and accumulated state into every prompt. Models do not use context uniformly — reliability degrades as input length grows. Quality degradation is not linear; it is non-linear and unpredictable. Vector embeddings used naively flatten code structure into undifferentiated chunks, destroying dependency relationships that agents need for multi-hop reasoning.

**How to avoid:**
Treat context as a finite budget, not a free resource. Design every agent to request the minimum context necessary for its task. Use structured tool calls to fetch specific facts rather than pre-loading large documents. Track token usage per agent call and emit a warning when an agent approaches 70% of its context budget. For code intelligence, preserve structural relationships (import graphs, call graphs) as metadata rather than raw file content. Test each agent at various context fill levels, not just at low fill.

**Warning signs:**
- Agents receive full file contents when they need specific functions or sections
- No per-call token counting at the agent layer
- Agents that "should remember" earlier steps produce inconsistent output in long runs
- Context assembly logic is a single function that appends everything available

**Phase to address:**
Phase 3 (Agent Context Assembly). Context budgeting must be designed before agents are built, not retrofitted.

---

### Pitfall 4: File-Based State Without Durability Guarantees

**What goes wrong:**
STATE.md, checkpoint files, and JSONL event logs are written, but when a process crashes mid-write, state is corrupted. Two concurrent agent executions resume from the same checkpoint simultaneously without a lock mechanism. After a crash, the system cannot distinguish a running workflow from an abandoned one. Coarse checkpointing means parallel agents that partially succeeded all re-execute on resume.

**Why it happens:**
Checkpointing (saving state) is mistaken for durable execution (guaranteeing completion). Most agent frameworks save state but leave failure detection, automatic recovery, and duplicate prevention to the application. Atomic file writes (temp file → rename) solve the write-corruption problem on POSIX but not the concurrency problem, and are not atomic on Windows. JSONL appends are not covered by the temp/rename pattern — appends require different protection (file locks or single-writer goroutine).

**How to avoid:**
Use atomic temp-file-then-rename for all full file writes (STATE.md, config, checkpoint files). For JSONL event logs, use a single-writer goroutine with a buffered channel — never write from multiple goroutines. Add a lock file or PID file for in-progress workflow runs so a new process can detect an abandoned run. Checkpoint at activity-level granularity, not superstep-level, so partial completions are not re-executed on resume. On Windows, test atomic writes explicitly — os.Rename is not atomic on Windows.

**Warning signs:**
- Multiple goroutines write to the same JSONL file without synchronization
- The system has no mechanism to detect a crashed-but-not-cleaned-up run
- Checkpoint resume re-runs steps that already wrote their outputs
- No integration test that kills the process mid-write and verifies state integrity on restart

**Phase to address:**
Phase 1 (State Persistence Layer). Durability contracts must be established before any agent writes state.

---

### Pitfall 5: Prompt Drift and Model Version Fragility

**What goes wrong:**
A provider silently upgrades the model behind a version alias (e.g., `gpt-4o` routes to a different snapshot). System prompts that were tuned to produce structured JSON output begin returning malformed JSON at a 40% rate. Agent pipelines built on strict output parsing break without any code change. Rollback is slow because no prompt versioning exists.

**Why it happens:**
Prompts are treated as configuration strings, not versioned artifacts with regression tests. LLM outputs are non-deterministic — the same prompt produces different outputs across model versions, even "minor" updates. In agentic systems, drift at any step spreads downstream. Teams edit prompts in response to feedback without running behavioral tests, treating it as safe because "it's just text."

**How to avoid:**
Version every system prompt alongside the code that consumes it. Build output shape tests for every structured-output prompt (not just "did it respond" but "does the response match the schema"). Use explicit model version pinning (e.g., `claude-3-5-sonnet-20241022`, not `claude-3-5-sonnet-latest`) in production. Test prompt changes against a golden output set before deploying. Log every LLM response with its prompt version and model version for post-hoc debugging.

**Warning signs:**
- System prompts are stored as string literals in Go source files without version identifiers
- Structured output parsing has no fallback or recovery for malformed responses
- Model aliases (latest, turbo) are used in production instead of pinned versions
- There are no regression tests that assert output schema compliance

**Phase to address:**
Phase 2 (Agent Runtime) and Phase 4 (Verification Gates). Prompt versioning in Phase 2; output schema validation in Phase 4.

---

### Pitfall 6: Cost Explosion from Unguarded Agent Loops

**What goes wrong:**
An agent enters a retry loop because its success criteria are not met. Each retry costs tokens. With 12+ agents, parallel execution, and no per-agent cost cap, a single bad run can consume the daily budget in minutes. A routing bug accidentally sends all tasks to the most expensive model. Cost tracking added after the fact misses early runs and provides no real-time budget enforcement.

**Why it happens:**
Cost tracking is treated as an observability concern rather than a runtime constraint. Agent retry logic has no maximum attempt count tied to cost thresholds. Rule-based routing is correct in nominal cases but has no fallback behavior that is validated against cost — a routing rule mismatch silently defaults to the most capable (most expensive) model.

**How to avoid:**
Design cost accounting into the agent execution protocol from day one, not as a post-hoc feature. Every agent call must record input tokens, output tokens, model ID, and cost estimate before the call completes. Implement hard per-run budget caps that halt execution and write a checkpoint before stopping. Retry limits must be enforced at the agent level, not assumed to be handled by provider SDKs. Validate routing rules in tests to ensure no task type falls through to an unintended model tier.

**Warning signs:**
- Token counting is added as a logging concern after agent execution logic is complete
- Retry logic has no maximum attempt count or cost-aware backoff
- Routing rules are tested for correctness but not for exhaustiveness (uncovered task types)
- No budget cap exists in the execution engine; cost is only visible in post-run reports

**Phase to address:**
Phase 1 (Provider Layer) — cost instrumentation must be part of the Provider interface, not added later.

---

### Pitfall 7: Spec-to-Code Drift in Agent-Generated Artifacts

**What goes wrong:**
GopherMind agents generate code that contradicts the spec they just wrote. Planning artifacts (SPEC.md, STATE.md) become stale as code evolves. The system passes its own verification gates because gates check for completeness, not semantic alignment with the original spec. After several sessions, the spec describes a system that no longer exists.

**Why it happens:**
LLM-generated code is non-deterministic — the same spec produces different implementations on different runs. Without bidirectional tracing (spec → code → spec), drift is invisible. Verification gates that check "does the code compile and test?" do not check "does the code match the architectural decisions in the spec?". Planning artifacts are written once and not re-validated as the codebase grows.

**How to avoid:**
Build spec-alignment checks into verification gates: after code generation, verify that key architectural decisions from the spec (package layout, interface names, patterns explicitly chosen) are present in the generated code. Maintain decision logs in STATE.md that record not just what was decided but why, so drift is detectable by reviewing against current code. Use deterministic scaffolding (package structure, interface stubs) generated from the spec before LLM-written implementation — the scaffold anchors the structure.

**Warning signs:**
- Verification gates only run `go build` and `go test`, not semantic checks
- STATE.md has not been updated after the last code generation run
- Planning artifacts use future tense ("will implement") after the implementation phase
- No test asserts that generated code implements the interfaces declared in the spec

**Phase to address:**
Phase 5 (Verification Gates). Define alignment checks as part of gate design.

---

## Technical Debt Patterns

| Shortcut | Immediate Benefit | Long-term Cost | When Acceptable |
|----------|-------------------|----------------|-----------------|
| Model alias (latest) instead of pinned version | No maintenance of version strings | Silent behavior changes break agent pipelines | Never in production |
| Single Provider struct instead of interface | Faster initial implementation | Cannot swap providers; cannot test with mock | Never — interface is the whole point |
| String-literal prompts in source | Simple, no extra files | No versioning, no regression tests, no diff tracking | MVP only if tests exist |
| Skip per-agent cost tracking, add later | Faster agent implementation | Cost explosion risk; retrofitting breaks the execution protocol | Never — instrument from day one |
| In-memory agent state, persist at end | Simpler code | All state lost on crash; no resumability | Never for a resumable system |
| Single JSONL writer without lock | Simpler code path | Log corruption under concurrent execution | Never — single-writer goroutine costs nothing |
| Viper flag binding without explicit getter | Intuitive flag access | Environment variable override silently ignored | Never — always use viper.Get* for configured values |

---

## Integration Gotchas

| Integration | Common Mistake | Correct Approach |
|-------------|----------------|------------------|
| Anthropic Messages API | Using `latest` model alias, missing streaming event types (`message_start`, `content_block_start`, `message_delta`) | Pin exact model versions; handle all SSE event types explicitly |
| OpenAI Chat Completions | Assuming usage tokens appear in every streaming chunk | Usage is only in the final chunk; accumulate across chunks |
| Google Gemini | Treating function_declarations as equivalent to OpenAI tools schema | Gemini's multimodal inputs (video, audio) are not abstracted away — handle Gemini-specific features explicitly |
| Ollama local | Assuming response structure matches OpenAI exactly | Ollama's OpenAI-compatibility mode is partial; streaming and tool-call support vary by model |
| Cobra + Viper config | Reading flag value directly from `cmd.Flag("x").Value.String()` after viper binding | Always use `viper.GetString("x")` after binding; flag defaults override env vars if read directly |
| JSONL event log | Multiple goroutines appending concurrently | Use a dedicated log-writer goroutine receiving from a buffered channel |
| Atomic file writes on Windows | Relying on os.Rename being atomic | os.Rename is not atomic on Windows; test cross-platform explicitly |
| Provider rate limits | Shared rate limiter across all models from same provider | Rate limits differ per model tier; maintain separate limiters per model |

---

## Performance Traps

| Trap | Symptoms | Prevention | When It Breaks |
|------|----------|------------|----------------|
| Naively assembling full file content into every prompt | Escalating costs, context window exhaustion, quality degradation | Fetch minimum required context per agent; use structural metadata not raw content | At 5+ files in a prompt |
| Unbound parallel agent goroutines | Simultaneous rate limit errors from provider; OS file descriptor exhaustion | Use errgroup with explicit goroutine limit; implement semaphore for LLM calls | At 3+ concurrent agents hitting the same provider |
| Accumulating all session history in every prompt | 7-second load times, 2GB memory pressure for long sessions | Summarize and compact history; use rolling window with importance scoring | At 500+ messages or 200K+ tokens of history |
| Superstep-level checkpointing with parallel agents | On resume, completed parallel work is duplicated | Checkpoint at activity level; track per-agent completion status | On any crash during parallel agent execution |
| Synchronous LLM calls on critical path during streaming output | User sees no output for 10+ seconds; perceived as hung | Use goroutines for concurrent LLM calls; stream partial results as they arrive | On any call with >2 second latency |

---

## Security Mistakes

| Mistake | Risk | Prevention |
|---------|------|------------|
| Sending full source tree to provider APIs | Source code exfiltrated to provider; violates privacy promise | Enforce explicit opt-in per-file or per-directory; default to no code transmission; log every API call with what was sent |
| API keys in config.json committed to git | Credential exposure in repository | Store keys in separate credentials file; add to .gitignore at project init; refuse to run if credentials.md is tracked by git |
| LLM-generated shell commands executed without review | Arbitrary code execution; data destruction | Require explicit human approval for any shell command an agent proposes; never auto-execute generated commands |
| Prompt injection via user-supplied project names or file content | Agent behavior manipulation; exfiltration of system prompts | Sanitize user inputs used in prompt construction; separate user content from system instructions using provider-supported roles |
| Logging full LLM responses including source code excerpts | Source code captured in logs; logs may be transmitted to monitoring services | Log response metadata (tokens, model, status) by default; log full response content only to local files with explicit configuration |

---

## UX Pitfalls

| Pitfall | User Impact | Better Approach |
|---------|-------------|-----------------|
| Silent progress during multi-minute agent runs | User kills the process thinking it hung; loses checkpoint | Stream structured progress events to stderr; show which agent is running, what it is doing, estimated tokens used |
| Generic "LLM error" messages without provider context | User cannot diagnose rate limits, quota exhaustion, or auth failures | Surface provider error codes with actionable remediation text (e.g., "Anthropic rate limit — retry in 30s, or switch to backup model") |
| `gophermind resume` with no disambiguation when multiple interrupted runs exist | Wrong run resumed silently | List interrupted runs with timestamp and last-known phase; require explicit selection |
| Cost report only available post-run | User discovers runaway cost after it has happened | Show running cost in progress output; emit a warning at configurable thresholds (e.g., 50% of budget) |
| Verification gate failures as unstructured error text | Developer cannot distinguish fixable failures from system errors | Categorize gate failures: COVERAGE (needs more tests), CONSISTENCY (spec drift), COMPLETENESS (missing implementation), ALIGNMENT (wrong architecture) |
| Cobra/Viper flag defaults silently overriding environment config | Configuration from environment is ignored without warning | Log effective configuration at startup at debug level; make config source visible in `gophermind config` output |

---

## "Looks Done But Isn't" Checklist

- [ ] **Provider interface:** Implementation handles all streaming event types for each provider — verify that Anthropic `message_start`, `content_block_start`, `content_block_delta`, `message_delta`, and `message_stop` are all handled, not just the delta events
- [ ] **Agent contracts:** Each agent has a machine-readable output schema, not just a description — verify by attempting to validate a sample output against the schema programmatically
- [ ] **Resumability:** Checkpoint restore actually recovers full execution context — verify by killing the process mid-run and checking that resume produces the same final output
- [ ] **Cost tracking:** Token counts are recorded for every provider call including failed calls — verify by searching JSONL logs for calls without cost records
- [ ] **Rate limiting:** Separate rate limiters exist per model tier, not just per provider — verify by checking limiter initialization code against provider rate limit documentation
- [ ] **Atomic writes:** All state file writes go through temp-file-rename pattern — verify by grepping for direct `os.WriteFile` calls on .planning/ paths
- [ ] **JSONL concurrency:** Event log has a single writer — verify with `-race` flag in tests that include concurrent agent execution
- [ ] **Prompt versioning:** System prompts have version identifiers that appear in JSONL logs — verify by reading log output and confirming prompt_version field is present
- [ ] **Windows compatibility:** Atomic rename behavior is tested on Windows — verify by checking test suite for OS-specific file write tests
- [ ] **Verification gates:** Gates check semantic alignment with spec, not just compilation and test pass — verify by intentionally introducing an architectural deviation and confirming the gate catches it

---

## Recovery Strategies

| Pitfall | Recovery Cost | Recovery Steps |
|---------|---------------|----------------|
| Provider abstraction semantic mismatch discovered in production | HIGH | Add per-provider behavioral test suite; audit all agent prompts against each provider; add provider-specific prompt variants where behavior diverges |
| Context window corruption (silent truncation) | MEDIUM | Add token counting middleware to all calls; replay affected runs with reduced context; add context budget enforcement before next run |
| Corrupted state file from concurrent write | MEDIUM | Restore from last valid checkpoint (requires checkpoint history); replay events from JSONL log up to corruption point; add write lock going forward |
| Prompt drift from model version change | MEDIUM | Roll back to pinned model version; run output schema tests against both versions; create per-version prompt variants if needed |
| Cost explosion from runaway agent loop | LOW (financially HIGH) | Set provider-level spending alerts immediately; add per-run budget cap; add agent retry limits; audit routing rules for unintended model selection |
| Spec-code drift discovered after multiple sessions | HIGH | Run alignment audit against each planning artifact; rebuild STATE.md from actual codebase state; treat accumulated drift as technical debt requiring a dedicated cleanup phase |
| Agent coordination failure (duplicate work, missed handoff) | MEDIUM | Replay from last checkpoint before the coordination failure; add explicit handoff validation; add contract tests for the affected agent pair |

---

## Pitfall-to-Phase Mapping

| Pitfall | Prevention Phase | Verification |
|---------|------------------|--------------|
| Provider abstraction semantic mismatch | Phase 1: Provider Layer | Behavioral contract tests pass against all configured providers |
| Underspecified agent contracts | Phase 2: Agent Runtime | All agent definitions have machine-readable input/output schemas; handoff validation rejects malformed output |
| Context window exhaustion | Phase 3: Context Assembly | Per-agent token budget enforced; warning emitted at 70% context fill |
| File-based state durability | Phase 1: State Persistence | Process-kill-and-resume test passes; JSONL log is intact after concurrent writes under `-race` |
| Prompt drift / model version fragility | Phase 2: Agent Runtime | All prompts have version IDs; output schema tests pass; model versions are pinned |
| Cost explosion | Phase 1: Provider Layer | Every provider call records cost; per-run budget cap halts execution; routing rules are exhaustiveness-tested |
| Spec-to-code drift | Phase 5: Verification Gates | Alignment gate catches architectural deviations; STATE.md is validated against codebase after each run |
| Cobra/Viper config override | Phase 1: CLI Foundation | Effective config is logged at startup; tests assert env vars take precedence over flag defaults |
| JSONL concurrent write corruption | Phase 1: State Persistence | `-race` tests pass with concurrent agent execution; log shows single-writer goroutine |
| LLM-generated command execution | Phase 2: Agent Runtime | No agent executes shell commands without emitting a HUMAN_APPROVAL_REQUIRED event |

---

## Sources

- [Why Do Multi-Agent LLM Systems Fail? — arXiv 2503.13657 (ICML 2025 Spotlight)](https://arxiv.org/abs/2503.13657): 14-category MAST taxonomy; 41-86.7% production failure rate; coordination failures account for 36.94% of all failures
- [Why Do Multi-Agent LLM Systems Fail? — Augment Code](https://www.augmentcode.com/guides/why-multi-agent-llm-systems-fail-and-how-to-fix-them): coordination and verification gap analysis
- [Still Not Durable: How Agent Frameworks Repeat the Same Mistakes — Diagrid](https://www.diagrid.io/blog/still-not-durable-how-microsoft-agent-framework-and-strands-agents-repeat-the-same-mistake): checkpointing vs durable execution; no failure detection; coarse checkpoint granularity
- [Provider-Agnostic Agents: Why Adapters Alone Aren't Enough — Florian Drechsler](https://fdrechsler.de/blog/provider-agnostic-agents): syntactic vs semantic abstraction gap; prompt portability costs; non-linear performance cliffs
- [The Context Window Problem — Factory.ai](https://factory.ai/news/context-window-problem): context exhaustion failure modes; bulk inclusion pitfall; multi-hop reasoning breakdown
- [Prompt Drift: The Hidden Failure Mode Undermining Agentic Systems — Comet](https://www.comet.com/site/blog/prompt-drift/): prompt drift definition; production failure from un-versioned prompt changes
- [How To Solve LLM Production Challenges — Deepchecks](https://deepchecks.com/llm-production-challenges-prompt-update-incidents/): prompt updates as primary source of production incidents
- [Comparing Streaming Response Structure for Different LLM APIs — Medium/Percolation Labs](https://medium.com/percolation-labs/comparing-the-streaming-response-structure-for-different-llm-apis-2b8645028b41): streaming incompatibilities between Anthropic, OpenAI, Google
- [Why Spec-Driven Development Fails — DEV Community](https://dev.to/casamia918/why-spec-driven-development-fails-and-what-we-can-learn-from-it-2pec): specification rot; AI ignoring its own spec; non-deterministic spec-to-code mapping
- [Sting of the Viper: Cobra + Viper Integration — Carolyn Van Slyck](https://carolynvanslyck.com/blog/2020/08/sting-of-the-viper/): flag default override issue; proper viper getter usage
- [Atomically Writing Files in Go — Michael Stapelberg](https://michael.stapelberg.ch/posts/2017-01-28-golang_atomically_writing/): temp-file-rename pattern; Windows non-atomicity; fsync requirement
- [Building a High-Performance LLM Client in Go — dasroot.net](https://dasroot.net/posts/2026/02/building-high-performance-llm-client-go/): concurrency model; connection pooling; error recovery
- [Common Concurrent Programming Mistakes — Go 101](https://go101.org/article/concurrent-common-mistakes.html): goroutine leak patterns; data races; channel deadlocks
- [Multi-Provider LLM Orchestration in Production — DEV Community](https://dev.to/ash_dubai/multi-provider-llm-orchestration-in-production-a-2026-guide-1g10): routing complexity; abstraction latency overhead; monitoring gaps
- [Detecting and Correcting Hallucinations in LLM-Generated Code via AST Analysis — arXiv 2601.19106](https://arxiv.org/html/2601.19106v1): Knowledge Conflicting Hallucinations; AST-based verification; 100% precision detection

---
*Pitfalls research for: GopherMind — multi-agent LLM orchestration platform in Go*
*Researched: 2026-03-20*